//////////////////////////////////
// BitArrayClass v1.0 by mistag
// ----------------------------
// Holds a variable, which can be accessed bitwise.
// Used to store an array of bits in one variable
// and to get/set all values as a whole variable (STOR_TYPE).
//
// Use and modify everything for your own needs!
//////////////////////////////////


#ifndef BITARRAYCLASS_H_INCLUDED
#define BITARRAYCLASS_H_INCLUDED


template <class STOR_TYPE>
class BitArrayClass {
private:
	STOR_TYPE storage;

public:
	BitArrayClass () : storage(NULL) {}
	BitArrayClass (STOR_TYPE pStorage) : storage(pStorage) {}
	~BitArrayClass () {}

	void setBit (unsigned char pos, int val)
	{
		if (pos > this->size()) throw "BitArrayClass::setBit out of range!";
		if( this->getBit(pos) && val == int(false) ) {
			this->storage -= ( 1 << pos );
		} else if( !this->getBit(pos) && val == int(true) ) {
			this->storage += ( 1 << pos );
		}
	}

	bool getBit (unsigned char pos)
	{
		if (pos > this->size()) throw "BitArrayClass::getBit out of range!";
		STOR_TYPE comp = 1 << pos;
		return ( ( this->storage & comp ) == comp );
	}

	STOR_TYPE getRange (unsigned char start, unsigned char end) {
		BitArrayClass<STOR_TYPE> tmpBA;
		for (unsigned char i = 0; i<=end-start; i++)
			tmpBA.setBit (i, this->getBit(start+i));
		return tmpBA.getStorage ();
	}

	void setRange (unsigned char start, unsigned char end, STOR_TYPE val) {
		BitArrayClass<STOR_TYPE> tmpBA (val);
		for (unsigned char i = 0; i<=end-start; i++)
			this->setBit (start+i, tmpBA.getBit(i));
		return;
	}

	int size () {
		return sizeof(STOR_TYPE)*8;
	}

	void setStorage (const STOR_TYPE newstor) { this->storage = newstor; }
	STOR_TYPE getStorage () { return this->storage; }

	bool operator [] (unsigned char i) { return this->getBit(i); }
	operator STOR_TYPE () { return this->storage; }
//	BitArrayClass* const operator = (const BitArrayClass<STOR_TYPE> other) { this->storage = other.getStorage(); return this; }
	operator = (const STOR_TYPE newstor) { this->storage = newstor; }
	operator bool() const { return this->storage != NULL; }
};

#endif // BITARRAYCLASS_H_INCLUDED