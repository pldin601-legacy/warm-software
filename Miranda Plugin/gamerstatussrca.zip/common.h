#ifndef COMMON_H_INCLUDED
#define COMMON_H_INCLUDED

#include "AggressiveOptimize.h" // modifies some MSVC-options to reduce file-size --> check http://nopcode.com/
#include <windows.h>
#include <stdio.h>

#include "../../miranda32/random/plugins/newpluginapi.h"
#include "../../miranda32/ui/contactlist/m_clist.h"
#include "../../miranda32/random/skin/m_skin.h"

#include "../../miranda32/database/m_database.h"
#include "../../miranda32/core/m_system.h"
#include "../../miranda32/protocols/protocols/m_protocols.h"
#include "../../miranda32/protocols/protocols/m_protosvc.h"
#include "../../miranda32/protocols/protocols/m_protomod.h"
#include "../../miranda32/ui/options/m_options.h"
#include "../../miranda32/random/langpack/m_langpack.h"

#include "m_popup.h"
#include "m_uninstaller.h" // soon to come ^^
#include "resource.h"
#include <commctrl.h>
#include <vector>
#include <string.h>
#include "BitArrayClass.h"
#include "mirandaDBtemplates.h"
using namespace std;

#include "defines.h"


class StringPair {
public:
	StringPair(string k, string v) : key(k), val(v) {}
	string key;
	string val;
};


///////////////
// VARIABLES //
///////////////
extern HINSTANCE hInst;
extern PLUGINLINK *pluginLink;
extern char *pluginid;

//extern BOOL cfgPluginEnabled;
//extern unsigned char cfgTimerInterval;
#define cfgTimerInterval cfgMainOptions.getRange (timerInterval_start, timerInterval_end)
extern BitArrayClass<int> cfgMainOptions;

extern UINT_PTR timerId;

/////////////////
// MY INCLUDES //
/////////////////
#include "helpers.h"
#include "statusBackupClass.h"
#include "processClass.h"
#include "protoManagerClass.h"
#include "awayProcessClass.h"
#include "processGroupClass.h"
#include "infoFileClass.h"

extern vector<processGroupClass> cfgGames;
extern void saveProcGroupCount();

#endif // COMMON_H_INCLUDED
