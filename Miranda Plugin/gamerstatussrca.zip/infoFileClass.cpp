// infoFileClass.cpp: Implementierung der Klasse infoFileClass.
//
//////////////////////////////////////////////////////////////////////

#include "common.h"

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

infoFileClass::infoFileClass() : index(0), fileAge(-1) {}
infoFileClass::infoFileClass(int pIndex, char *pFilePath)
: index(pIndex)
{
	strncpy(this->filePath, pFilePath, MAX_PATH);
	this->fileAge = FileAge(this->filePath); // returns -1 if file does not exist
}

infoFileClass::~infoFileClass() {}

BOOL infoFileClass::parseFile() { return FALSE; }

void infoFileClass::replaceData(char *target) {
	int i;
	char tmp[128];

	for(i=0; i<this->fileData.size(); i++) {
		sprintf(tmp, "%%li_%s%%", this->fileData[i].key.c_str());
		replace(target, tmp, this->fileData[i].val.c_str());
	}

	return;
}

void infoFileClass::cleanLineBreaks(char *str) {
	replace(str, "\r", "");
	replace(str, "\n", "");
	return;
}

void infoFileClass::refreshFileAge() {
	this->fileAge = FileAge(this->filePath); // returns -1 if file does not exist
}



/////////////////////
// launchInfoClass //
/////////////////////
launchInfoClass::launchInfoClass() : infoFileClass () {}
launchInfoClass::launchInfoClass(int pIndex, char *pFilePath) : infoFileClass (pIndex,pFilePath) {}
launchInfoClass::~launchInfoClass() {}

BOOL launchInfoClass::parseFile() {
	FILE *f;

	f = fopen(this->filePath, "r");
	if (f==NULL) {
		popup(POPUP_TITLE, POPUP_INFOFILEOPENERROR);
		return FALSE;
	} else {
		int keyLen, valStart;
		char tmp[1024];
		string cLine;

		while(!feof(f)) {
			fgets(tmp, sizeof(tmp), f);
			cleanLineBreaks(tmp);
			
			// work-around because fgets seems to give the previous line again if the current line is empty
			if (cLine.compare(tmp) == 0) continue;
			cLine = tmp;

			keyLen = cLine.find_first_of(" ");
			valStart = keyLen + 1;
			if (keyLen != 0 && cLine.size() > keyLen + 1) {
				this->fileData.push_back(
					StringPair(
						cLine.substr(0,keyLen),
						cLine.substr(valStart,cLine.size()-valStart)
					)
				);
			}
		}

		fclose(f);
	}

	return !this->fileData.empty();
}