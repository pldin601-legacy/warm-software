#ifndef ENUMPROCS_H_INCLUDED
#define ENUMPROCS_H_INCLUDED

#include <tlhelp32.h>
#include <vdmdbg.h>

typedef BOOL (CALLBACK *PROCENUMPROC)(DWORD, WORD, LPSTR, LPARAM);

extern "C" BOOL initEnumProcs();
extern "C" void shutdownEnumProcs();
extern "C" BOOL WINAPI EnumProcs(PROCENUMPROC lpProc, LPARAM lParam);

#endif // ENUMPROCS_H_INCLUDED