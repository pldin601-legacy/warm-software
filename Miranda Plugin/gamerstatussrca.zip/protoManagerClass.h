// protoManagerClass.h: Schnittstelle f�r die Klasse protoManagerClass.
//
//////////////////////////////////////////////////////////////////////

#ifndef PROTOMANAGERCLASS_H_INCLUDED
#define PROTOMANAGERCLASS_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "common.h"
class awayProcessClass;

class protoManagerClass
{
private:
	struct protoData {
		protoData (char *pName) : name(pName), isIgnored(FALSE), isLoaded(TRUE), isTempIgnored(FALSE) {}
//		protoData (char *pName, int pType) : name(pName), type(pType), isIgnored(FALSE), isTempIgnored(FALSE) {}
		protoData (char *pName, BOOL pDisabled, BOOL pLoaded)
			: name(pName), isIgnored(pDisabled), isLoaded(pLoaded), isTempIgnored(FALSE) {}
		virtual ~protoData() {}

		string name;
//		int type; // see m_protocols.h
		BOOL isIgnored;
		BOOL isLoaded;
		BOOL isTempIgnored;
	};
	vector<protoData> protos;

	bool ignoreStatusChange;

	int byName (string search) {
		int i;
		for (i=0; i<this->protos.size(); i++)
			if (protos[i].name.compare(search) == 0)
				return i;
		return -1;
	}

public:
	protoManagerClass () : ignoreStatusChange(false) {} //, mirandaIsClosing(false) {}
	virtual ~protoManagerClass() {}

//	bool mirandaIsClosing;

	int userStatusChange (char*,int,awayProcessClass*);

	bool ignoredProtos () {
		int i;
		for (i=0; i<this->protos.size(); i++)
			if (this->protos[i].isIgnored || this->getStatus(i) == ID_STATUS_OFFLINE)
				return true;
		return false;
	}

	void load () {
		int protoCount,i;
		PROTOCOLDESCRIPTOR **tmpProtos;

		protos.clear();
		CallService(MS_PROTO_ENUMPROTOCOLS,(WPARAM)&protoCount,(LPARAM)&tmpProtos);
		for(i=0;i<protoCount;i++) {
			if (tmpProtos[i]->type != PROTOTYPE_PROTOCOL) continue;
			
			protos.push_back (protoData(tmpProtos[i]->szName));
		}

		this->DBLoad();
	}

	BOOL isIgnored (int i) { return protos[i].isIgnored; }
	BOOL isIgnored (char *s) {
		int i = byName(string(s));
		return (i == -1) ? FALSE : this->protos[i].isIgnored;
	};
	int getStatus (int i) { return CallProtoService (this->protos[i].name.c_str(), PS_GETSTATUS, 0, 0); }
	int getStatus (char *s) { return CallProtoService (s, PS_GETSTATUS, 0, 0); }
	

	bool perform (int statusMode, char *statusMsg, bool onlyOnline, statusBackupClass *backupClass, bool setStatus) {
		int i, tmpStatus;
		bool action=false;

		if (setStatus) this->ignoreStatusChange = true;
		for (i=0; i<protos.size(); i++) {

			// checks
			if (protos[i].isIgnored) continue;
			tmpStatus = this->getStatus(i);
			if (tmpStatus == ID_STATUS_OFFLINE) continue;
			if (onlyOnline && tmpStatus != ID_STATUS_ONLINE) continue;

			// actions
			if (backupClass == NULL && !setStatus) return true;
			action = true;
			if (backupClass != NULL) backupClass->add (protos[i].name, tmpStatus);
			if (setStatus) setProtoStatus (protos[i].name.c_str(), statusMode, statusMsg);
		}
		if (setStatus && (action || cfgMainOptions[alwaysGlobal]))
			this->setGlobalStatus (statusMode, statusMsg);

		if (setStatus) this->ignoreStatusChange = false;
		return action;
	}

	bool isStatus (int checkStatus, bool atLeastOne) {
		int i;
		for (i=0; i<this->protos.size(); i++) {
			if (getStatus(i) == checkStatus) {
				if (atLeastOne) return true;
			} else if (!atLeastOne) return false; // all protos should have checkStatus, but this one hasn't
		}
		return true;
	}

	void exportList (HWND hList) {
		int i;
		LV_ITEM lvi;

		ListView_DeleteAllItems(hList);

		ZeroMemory(&lvi, sizeof(lvi));
		lvi.mask=LVIF_TEXT;   // Text Style
		lvi.cchTextMax = maxProcessLen; // Max size of text

		for(i=0; i<this->protos.size(); i++) {    
			lvi.iItem=i; // choose item
			lvi.iSubItem=0; // Put in first column
			lvi.pszText=(char*)this->protos[i].name.c_str(); // Text to display (can be from a char variable) (Items)
			SendMessage(hList, LVM_INSERTITEM, 0, (LPARAM)&lvi); // Send to the Listview

			// set check-box
//			ListView_SetCheckState (hList, i, this->protos[i].isIgnored);
			ListView_SetItemState (hList, i, UINT((int(this->protos[i].isIgnored) + 1) << 12), LVIS_STATEIMAGEMASK);
		}
	}

	void importList (HWND hwnd) {
		int i, lItemCount = ListView_GetItemCount(hwnd);
		
		for (i=0; i<lItemCount; i++) {
			this->protos[i].isIgnored = ListView_GetCheckState(hwnd, i);
		}
	}

	void DBSave () {
		int i, count=0, oldCount = GetDBByte ("disabledProtoCount", -1);
		if (count == -1) return;

		for (i=0; i<this->protos.size(); i++) {
			if (!this->protos[i].isIgnored) continue;
			SetDBString ("disabledProto%i", count++, this->protos[i].name.c_str());
		}

		if (oldCount > count)
			for (i=count; i<oldCount; i++)
				DBDel ("disabledProto%i", i);

		SetDBByte ("disabledProtoCount", count);
	}

	void DBLoad () {
		int i, tmpIndex, count = GetDBByte ("disabledProtoCount", -1);
		char tmpName[32];
		if (count == -1) return;

		for (i=0; i<count; i++) {
			GetDBString (tmpName, "disabledProto%i", i, sizeof(tmpName), "");
			if (tmpName == "") continue;

			tmpIndex = this->byName (string(tmpName));
			if (tmpIndex == -1) {
				this->protos.push_back (protoData(tmpName,true,false));
			} else {
				this->protos[tmpIndex].isIgnored = true;
			}
		}

	}

	void DBDelete () {
		int i, count = GetDBByte ("disabledProtoCount", -1);
		if (count == -1) return;

		for (i=0; i<count; i++)
			DBDel ("disabledProto%i", i);

		DBDel ("disabledProtoCount");
	}

	void setGlobalStatus(int mode, char *msg)
	{
		if (!cfgMainOptions[alwaysGlobal])
			if (this->ignoredProtos())
				return; // dont set global status if at least one protocol is ignored or offline

//		popup("GLOBAL STATUS", (msg==NULL)?"":msg);

		//awaysys support
		if (ServiceExists(MS_AWAYSYS_SETSTATUSMODE)) {
			CallService(MS_AWAYSYS_SETSTATUSMODE, mode, (LPARAM)msg);
		} else {
			byte x = DBGetContactSettingByte(NULL, "SRAway", StatusModeToDbSetting(mode, "NoDlg"), 0);
			DBWriteContactSettingByte(NULL, "SRAway", StatusModeToDbSetting(mode, "NoDlg"), 1);

			CallService(MS_CLIST_SETSTATUSMODE, mode,0);
			CallService(PS_SETAWAYMSG, mode, (LPARAM)msg);

			DBWriteContactSettingByte(NULL, "SRAway", StatusModeToDbSetting(mode, "NoDlg"), x);
		}

		return;
	}

	char *StatusModeToDbSetting(int status,const char *suffix)
	{
		char *prefix;
		static char str[64];

		switch(status) {
			case ID_STATUS_AWAY: prefix="Away";	break;
			case ID_STATUS_NA: prefix="Na";	break;
			case ID_STATUS_DND: prefix="Dnd"; break;
			case ID_STATUS_OCCUPIED: prefix="Occupied"; break;
			case ID_STATUS_FREECHAT: prefix="FreeChat"; break;
			case ID_STATUS_ONLINE: prefix="On"; break;
			case ID_STATUS_OFFLINE: prefix="Off"; break;
			case ID_STATUS_INVISIBLE: prefix="Inv"; break;
			case ID_STATUS_ONTHEPHONE: prefix="Otp"; break;
			case ID_STATUS_OUTTOLUNCH: prefix="Otl"; break;
			default: return NULL;
		}
		lstrcpy(str,prefix); lstrcat(str,suffix);

		return str;
	}

	void debugpopup() {
		string tmp("detected protocols:"), linebreak("\n");
		int j;

		for (j=0; j<this->protos.size(); j++) {
			tmp += linebreak;
			tmp += string(this->protos[j].name);
		}
		popup("detected protocols", tmp.c_str());
	}
};

#endif // PROTOMANAGERCLASS_H_INCLUDED
