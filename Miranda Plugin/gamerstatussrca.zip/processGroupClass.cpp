// processGroupClass.cpp: Implementierung der Klasse processGroupClass.
//
//////////////////////////////////////////////////////////////////////

#include "common.h"

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

processGroupClass::processGroupClass()
{
	throw "Default constructor of processGroupClass called.";
}

processGroupClass::processGroupClass(int pIndex, BOOL init)
: index(pIndex), litem(-1), DBSettingsLoaded(FALSE)
{
	if (!init) return;
	if (!this->loadBasicData()) {
		throw "processGroupClass initialization failed!";
	}
}

processGroupClass::processGroupClass(int pIndex, char *pGroupName, char *pProcessName, char *pAppName, char *pAwayMessage, unsigned int pAwayStatus, int pOptions)
: index(pIndex), litem(-1), DBSettingsLoaded(TRUE), awayStatus(ID_STATUS_OCCUPIED), options(pOptions)
{
	this->processNames.push_back(string(pProcessName));
	this->appNames.push_back(string(pAppName));
	this->init(pGroupName, pAwayMessage);
}

processGroupClass::processGroupClass(int pIndex, char *pGroupName, char *pProcessNames[], char *pAppNames[], int defProcCount, char *pAwayMessage, unsigned int pAwayStatus, int pOptions)
: index(pIndex), litem(-1), DBSettingsLoaded(TRUE), awayStatus(ID_STATUS_OCCUPIED), options(pOptions)
{
	int i;
	for (i=0; i<defProcCount; i++) {
		this->processNames.push_back(string(pProcessNames[i]));
		this->appNames.push_back(string(pAppNames[i]));
	}
	this->init(pGroupName, pAwayMessage);
}

processGroupClass::~processGroupClass() // has made problems when deleting some items from the vector
{
//	popup("destructor called", "cfgGames[%i]", this->index);
//	this->freeDBSettings();
//	this->processNames.clear();
}

void processGroupClass::init(char *pGroupName, char *pAwayMessage) {
	this->groupName = new char[maxProcessLen];
	strncpy(this->groupName, pGroupName, maxProcessLen);

	this->awayMessage = new char[maxStatusMsgLen];
	strncpy(this->awayMessage, pAwayMessage, maxStatusMsgLen);

	this->saveDBSettings();
	this->freeDBSettings();
}

BOOL processGroupClass::loadBasicData() {
	char tmp[16], tmp2[maxProcessLen];
	int i, processCount = GetDBWord("processCount%i", this->index, -1);

	if(processCount == -1) return FALSE;
	sprintf(tmp, "process%i_", this->index);
	strcat(tmp, "%i");

	for (i=0; i<processCount; i++) {
		GetDBString(tmp2, tmp, i, maxProcessLen, "");
		if (strcmp(tmp2,"") != 0) this->processNames.push_back(string(tmp2));
	}

	this->options.setStorage(GetDBWord("options%i", this->index, NULL));

	return TRUE;
}

BOOL processGroupClass::loadDBSettings() {
	if (this->DBSettingsLoaded) return FALSE;
	
	char tmpkey[maxProcessLen], tmpval[maxProcessLen];
	int i, procCount = GetDBWord("processCount%i", this->index, -1);

	sprintf(tmpkey, "app%i_", this->index);
	strcat(tmpkey, "%i");

	this->appNames.clear();

	for(i=0; i<procCount; i++) {
		GetDBString(tmpval, tmpkey, i, sizeof(tmpval), "ERROR");
		this->appNames.push_back(string(tmpval));
	}


	this->awayStatus = GetDBWord("statusMode%i", this->index, ID_STATUS_OCCUPIED);

	this->groupName = new char[maxProcessLen];
	GetDBString(this->groupName, "group%i", this->index, maxProcessLen, "ERROR");
//	popup("loaded groupName = %s", this->groupName);

	this->awayMessage = new char[maxStatusMsgLen];
	GetDBString(this->awayMessage, "statusMessage%i", this->index, maxStatusMsgLen, "I'm occupied");
//	popup("loaded awayMessage = %s", this->awayMessage);

	this->DBSettingsLoaded = TRUE;
	return TRUE;
}

BOOL processGroupClass::saveDBSettings() {
	if (!this->DBSettingsLoaded) return FALSE;

	char tmp[32], tmp2[32];
	int i, prevProcCount = GetDBWord("processCount%i", this->index, -1);

	SetDBWord("processCount%i", this->index, this->processNames.size());

	sprintf(tmp, "process%i_", this->index);
	strcat(tmp, "%i");
	sprintf(tmp2, "app%i_", this->index);
	strcat(tmp2, "%i");
	for (i=0; i<this->processNames.size(); i++) {
		SetDBString(tmp, i, this->processNames[i].c_str());
		SetDBString(tmp2, i, this->appNames[i].c_str());
	}
	if (prevProcCount != -1 && prevProcCount > this->processNames.size()) {
		// work-around to avoid crash, if all processes of a group are removed
		int newProcCount = this->processNames.size();
		if (this->processNames.empty()) newProcCount = 0;

		for (i=prevProcCount-1; i>=newProcCount; i--) {
			DBDel(tmp, i);
			DBDel(tmp2, i);
		}
	}

	SetDBString("group%i", this->index, this->groupName);
	SetDBWord("statusMode%i", this->index, this->awayStatus);
	SetDBWord("options%i", this->index, this->options.getStorage());
	SetDBString("statusMessage%i", this->index, this->awayMessage);

	return TRUE;
}

void processGroupClass::deleteDBSettings() {
	int i, procCount = GetDBWord("processCount%i", this->index, -1);
	char tmp[32], tmp2[32];
	sprintf(tmp, "process%i_", this->index);
	strcat(tmp, "%i");
	sprintf(tmp2, "app%i_", this->index);
	strcat(tmp2, "%i");
	for (i=0; i<procCount; i++) {
		DBDel(tmp, i);
		DBDel(tmp2, i);
	}
	DBDel("processCount%i", this->index);

	DBDel("group%i", this->index);
	DBDel("game%i", this->index);
	DBDel("statusMode%i", this->index);

	DBDel("options%i", this->index);

	DBDel("statusMessage%i", this->index);
}

BOOL processGroupClass::freeDBSettings() {
	if (!this->DBSettingsLoaded) return FALSE;
	try {
		delete[] this->awayMessage;
		delete[] this->groupName;
	} catch (char * str) {
		popup(POPUP_TITLE, str);
	}
	this->appNames.clear();

	this->DBSettingsLoaded = FALSE;
	return TRUE;
}


int processGroupClass::processLookUp(string *runningProcess) {
	for (int i=0; i<this->processNames.size(); i++)
		if (stricmp(this->processNames[i].c_str(), runningProcess->c_str()) == 0)
			return i;
	return -1;
}
/*
void processGroupClass::getAppName(string *target, int i) {
	if (this->appNames.empty() || this->appNames.size() <= i) { // load it
		char tmp[32], tmpval[maxProcessLen];

		sprintf(tmp, "app%i_", this->index);
		strcat(tmp, "%i");
		GetDBString(tmpval, tmp, i, maxProcessLen, "???");
		*target = string(tmpval);

	} else { // already loaded
		*target = this->appNames[i];
	}
	return;
}
*/
processClass processGroupClass::getProcess (int i) {
	processClass tmpProc (this, this->processNames.at(i));

	if (this->appNames.empty() || this->appNames.size() <= i) { // load it
		char tmp[32], tmpval[maxProcessLen];

		sprintf(tmp, "app%i_", this->index);
		strcat(tmp, "%i");
		GetDBString(tmpval, tmp, i, maxProcessLen, "???");
		tmpProc.appname = string(tmpval);

	} else { // already loaded
		tmpProc.appname = this->appNames[i];
	}	

	return tmpProc;
}

int processGroupClass::setListItem(HWND hwnd) {  // returns the item-id
	if(this->litem == -1) {
		LV_ITEM lvi;

		ZeroMemory(&lvi, sizeof(lvi)); // LV_ITEM
		lvi.iItem = this->index;
		lvi.mask = LVIF_PARAM; //LVIF_TEXT|LVIF_PARAM;
		lvi.lParam = (LPARAM)this->index;
		this->litem = ListView_InsertItem(hwnd, &lvi);
		this->hProcGroupList = hwnd;
	}
	char tmp[8];
	sprintf(tmp, "%i", this->processNames.size());

	ListView_SetItemText(hwnd, this->litem, 0, this->groupName); // this->groupName
	ListView_SetItemText(hwnd, this->litem, 1, tmp);
	ListView_SetItemText(hwnd, this->litem, 2, (char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, this->awayStatus, 0));
	ListView_SetItemText(hwnd, this->litem, 3, this->options[setStatusBack]?strYes:strNo);
	ListView_SetItemText(hwnd, this->litem, 4, this->options[popupNotify]?strYes:strNo);
	ListView_SetItemText(hwnd, this->litem, 5, this->options[onlyFromOnline]?strYes:strNo);
	ListView_SetItemText(hwnd, this->litem, 6, this->options[disablePopups]?strYes:strNo);
	ListView_SetItemText(hwnd, this->litem, 7, this->options[disableSounds]?strYes:strNo);

	return this->litem;
}

BOOL processGroupClass::removeListItem() {
	if(this->litem == -1) return FALSE;
	ListView_DeleteItem(this->hProcGroupList, this->litem);
	this->resetDialogVars();
	return TRUE;
}
/*
void processGroupClass::readdListItem() {
	if(this->litem == -1) return;
	HWND tmp = this->hProcGroupList;

	this->removeListItem();
	this->setListItem(tmp, strYes, strNo);
	return;
}
*/
int processGroupClass::exportPropertyDlg(HWND hwndDlg) {
	char tmp[maxStatusMsgLen];

	// dialog
	sprintf(tmp, "Properties: %s", this->groupName);
	SetDlgItemText(hwndDlg, IDD_OPT_PROCGROUP, tmp);

	// groupName
	SetDlgItemText(hwndDlg, IDC_GROUPNAME, this->groupName);

	// statusmsg
	SetDlgItemText(hwndDlg, IDC_STATUSMSG, this->awayMessage);

	// combobox
	SendMessage(GetDlgItem(hwndDlg, IDC_STATUS), CB_SELECTSTRING, -1, (LPARAM)(char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, this->awayStatus, 0));
	
	// checkboxes
	{
		int i, checkboxes[] = {IDC_SETBACK, IDC_POPUPNOTIFY, IDC_ONLYFROMONLINE, IDC_DISABLEPOPUPS, IDC_DISABLESOUNDS, IDC_CHECK_SETSTATUS};
		for (i=0; i<sizeof(checkboxes)/sizeof(int); i++)
			SendMessage (GetDlgItem(hwndDlg, checkboxes[i]), BM_SETCHECK, this->options[i]?BST_CHECKED:BST_UNCHECKED, 0);
		SendMessage (hwndDlg, WM_COMMAND, IDC_CHECK_SETSTATUS, NULL);
	}
	SetDlgItemInt(hwndDlg, IDC_EDIT_ACTDELAY, this->options.getRange(activationDelay_start, activationDelay_end) , FALSE);
	SetDlgItemInt(hwndDlg, IDC_EDIT_DEACTDELAY, this->options.getRange(deactivationDelay_start, deactivationDelay_end) , FALSE);

	// process-list
	int i;
	LV_ITEM lvi;
	HWND hwnd = GetDlgItem(hwndDlg, IDC_PROCESSLIST);

	ListView_DeleteAllItems(hwnd);

	ZeroMemory(&lvi, sizeof(lvi));
	lvi.mask=LVIF_TEXT;   // Text Style
	lvi.cchTextMax = maxProcessLen; // Max size of text

	for(i=0; i<this->processNames.size(); i++) {    
		lvi.iItem=i; // choose item

		// insert key
		lvi.iSubItem=0; // Put in first column
		lvi.pszText=(char*)this->processNames[i].c_str(); // Text to display (can be from a char variable) (Items)
		SendMessage(hwnd, LVM_INSERTITEM, 0, (LPARAM)&lvi); // Send to the Listview

		// insert value
		lvi.iSubItem=1;
		lvi.pszText=(char*)this->appNames[i].c_str();
		SendMessage(hwnd, LVM_SETITEM, 0, (LPARAM)&lvi); // Send to the Listview

	}

	return this->index;
}

void processGroupClass::importPropertyDlg(HWND hwndDlg) {
	long tmpStatus;
	HWND hwnd;

	// groupname
	this->groupName = new char[maxProcessLen];
	GetDlgItemText(hwndDlg, IDC_GROUPNAME, this->groupName, maxProcessLen);

	// statusmsg
	this->awayMessage = new char[maxStatusMsgLen];
	GetDlgItemText(hwndDlg, IDC_STATUSMSG, this->awayMessage, maxStatusMsgLen);

	// status-combobox
	hwnd = GetDlgItem(hwndDlg, IDC_STATUS);
	tmpStatus = SendMessage(hwnd, CB_GETCURSEL, 0, 0);
	if (tmpStatus == CB_ERR) tmpStatus = 0;
	tmpStatus=SendMessage(hwnd, CB_GETITEMDATA, tmpStatus, 0);
	if (tmpStatus == CB_ERR) tmpStatus = ID_STATUS_ONLINE;
	this->awayStatus = tmpStatus;
	
	// checkboxes
	{
		int i, checkboxes[] = {IDC_SETBACK, IDC_POPUPNOTIFY, IDC_ONLYFROMONLINE, IDC_DISABLEPOPUPS, IDC_DISABLESOUNDS, IDC_CHECK_SETSTATUS};
		for (i=0; i<sizeof(checkboxes)/sizeof(int); i++)
			this->options.setBit(i, GetCheckVal(hwndDlg, checkboxes[i]));
	}
	this->options.setRange (activationDelay_start, activationDelay_end, GetDlgItemInt(hwndDlg, IDC_EDIT_ACTDELAY, NULL, FALSE));
	this->options.setRange (deactivationDelay_start, deactivationDelay_end, GetDlgItemInt(hwndDlg, IDC_EDIT_DEACTDELAY, NULL, FALSE));

	// process-list
	hwnd = GetDlgItem(hwndDlg, IDC_PROCESSLIST);
	char tmp[32];
	int i, lItemCount = ListView_GetItemCount(hwnd);

	this->processNames.clear();
	this->appNames.clear();

	for (i=0; i<lItemCount; i++) {
		ListView_GetItemText(hwnd, i, 0, tmp, sizeof(tmp));
		this->processNames.push_back(string(tmp));

		ListView_GetItemText(hwnd, i, 1, tmp, sizeof(tmp));
		this->appNames.push_back(string(tmp));
	}
	this->DBSettingsLoaded = TRUE;
}

void processGroupClass::resetDialogVars() {
	this->litem = -1;
	this->hProcGroupList = NULL;
	return;
}

void processGroupClass::changeIndex(int newIndex) {
	BOOL free = this->loadDBSettings();
	this->deleteDBSettings();
	this->index = newIndex;
	this->saveDBSettings();
	if (free) this->freeDBSettings();

	return;
}

void processGroupClass::debugpopup() {
	string tmp, linebreak("\n");
	int j;

	for (j=0; j<this->processNames.size(); j++) {
		tmp += this->processNames[j];
		tmp += linebreak;
	}
	popup(this->groupName, tmp.c_str());
	
}