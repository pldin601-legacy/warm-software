#ifndef STATUSBACKUPCLASS_INCLUDED
#define STATUSBACKUPCLASS_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "common.h"

class statusBackupClass {
private:
	class protoStatus {
	public:
		protoStatus (string pProtoName)
		: protoName(pProtoName), statusMsg(NULL)
		{
			statusMode = CallProtoService (protoName.c_str(), PS_GETSTATUS, 0, 0);
			this->getStatusMsg();
			return;
		}
		protoStatus (string pProtoName, int pStatusMode)
		: protoName(pProtoName), statusMode(pStatusMode), statusMsg(NULL)
		{
			this->getStatusMsg();
			return;
		}
		virtual ~protoStatus() {}

		string protoName;
		int statusMode;
		char *statusMsg;

		void getStatusMsg () {
//			if (ServiceExists(MS_AWAYMSG_GETSTATUSMSG))
//				this->statusMsg = (char*)CallService(MS_AWAYMSG_GETSTATUSMSG, (WPARAM)this->statusMode, 0);
			return;
		}
	};
	vector<protoStatus> protos;

public:
	void add (string protoName, int statusMode) { protos.push_back(protoStatus(protoName, statusMode)); }
	void del (string protoName) {
		int i;
		for (i=0; i<this->protos.size(); i++) {
			if (protoName.compare(this->protos[i].protoName) == 0) {
				vector<protoStatus>::iterator p = &this->protos[i];
				this->protos.erase(p);
				break;
			}
		}
		vector<protoStatus>(protos).swap(protos); // shrinks the vector to the needed size --> see protos.capacity()
		return;
	}

	void clear () { protos.clear(); }
	void restoreAll () {
		int i;
		for (i=0; i<protos.size(); i++) {
			setProtoStatus (protos[i].protoName.c_str(), protos[i].statusMode, protos[i].statusMsg);
		}
	}	
	int firstStatus () { return (this->protos.empty())?0:this->protos[0].statusMode; }

	void DBSave () {
		int i;
		SetDBByte (awayProcProtoCount, this->protos.size());
		for (i=0; i<this->protos.size(); i++) {
			SetDBString (awayProcProtoName, i, protos[i].protoName.c_str());
			SetDBWord (awayProcProtoStatus, i, protos[i].statusMode);
		}
		return;
	}

	void DBDelete () {
		int i;
		DBDel (awayProcProtoCount);
		for (i=0; i<this->protos.size(); i++) {
			DBDel (awayProcProtoName, i);
			DBDel (awayProcProtoStatus, i);
		}
		return;
	}

	bool DBLoad () {
		int i, tmpCount = GetDBByte (awayProcProtoCount, -1);
		if (tmpCount == -1) return false;
		char tmpName[32];
		bool loaded=false;

		for (i=0; i<tmpCount; i++) {
			GetDBString (tmpName, awayProcProtoName, i, sizeof(tmpName), "");
			if (tmpName != "") {
				this->protos.push_back(protoStatus(string(tmpName), GetDBWord (awayProcProtoStatus, i, ID_STATUS_ONLINE)));
				loaded = true;
			}
		}
		return loaded;
	}	


	void debugpopup () {
		string tmp("backup protocols:"), linebreak("\n");
		int j;
		char asd[128];

		for (j=0; j<this->protos.size(); j++) {
			tmp += linebreak;
			sprintf (asd, "%s : %i", protos[j].protoName.c_str(), protos[j].statusMode);
			tmp += string(asd);
		}
		popup("backup protocols", tmp.c_str());
	}

	operator bool() const { return !this->protos.empty(); }
};

#endif // STATUSBACKUPCLASS_INCLUDED