// infoFileClass.h: Schnittstelle f�r die Klasse infoFileClass.
//
//////////////////////////////////////////////////////////////////////

#ifndef INFOFILECLASS_H_INCLUDED
#define INFOFILECLASS_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class infoFileClass  
{
public:
	infoFileClass();
	infoFileClass(int,char*);
	virtual ~infoFileClass();

	int index;
	char filePath[MAX_PATH];
	double fileAge;

	vector<StringPair> fileData;

	virtual BOOL parseFile();

	void replaceData(char*);
	void cleanLineBreaks(char*);
	void refreshFileAge();
	void clear() { this->fileData.clear(); }
	string getKey (int i) { return this->fileData.at(i).key; }
	string getVal (int i) { return this->fileData.at(i).val; }
	string getVal (string search) {
		int i;
		for (i=0; i<this->fileData.size(); i++)
			if (this->fileData[i].key.compare(search)==0)
				return this->fileData[i].val;
		return NULL;
	}

	operator bool() const { return !this->fileData.empty(); }
};

class launchInfoClass : public infoFileClass
{
public:
	launchInfoClass();
	launchInfoClass(int,char*);
	virtual ~launchInfoClass();

	BOOL parseFile();
};

#endif // INFOFILECLASS_H_INCLUDED
