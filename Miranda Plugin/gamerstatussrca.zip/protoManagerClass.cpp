#include "common.h"

int protoManagerClass::userStatusChange (char *protoName, int newStatus, awayProcessClass *awayProcess) {
//	popup("status-change", "not active : %i\nignored : %i\nglobal : %i", !awayProcess->isActive, this->ignoreStatusChange, (protoName == NULL));
//	popup((protoName==NULL)?"_GLOBAL_":protoName, "this->ignoreStatusChange : %i", this->ignoreStatusChange);

	if (!awayProcess->isActive || this->ignoreStatusChange) return 0;
	
	if (protoName == NULL) { // global status change
		awayProcess->isIgnored = TRUE;
		awayProcess->deactivate(POPUP_DISABLE, FALSE);
	} else { // protocol status change
		awayProcess->statusBackup.del (string(protoName));
		if (!awayProcess->statusBackup) {
			awayProcess->deactivate(POPUP_DISABLE, FALSE);
			awayProcess->isIgnored = TRUE;
		} else popup (pluginid, POPUP_DISABLEPROTO, protoName);
	}
	return 0;
}