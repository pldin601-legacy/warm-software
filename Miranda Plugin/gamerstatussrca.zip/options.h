
extern int CALLBACK mainOptionsDlg(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
