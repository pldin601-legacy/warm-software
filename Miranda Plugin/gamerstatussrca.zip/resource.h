//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_OPT_CFG                     101
#define IDD_OPT_HELP                    103
#define IDD_OPT_LAUNCHINFO              104
#define IDD_OPT_PROCGROUP               105
#define IDC_EDIT_INTERVAL               1000
#define IDC_EDIT_PROCESS                1001
#define IDC_EDIT_LAUNCHINFO             1002
#define IDC_EDIT_ICQ_ST                 1010
#define IDC_CHECK_ICQ_SETBACK           1011
#define IDC_CHECK_POPUPS                1012
#define IDC_CHECK_ONLYFROMONLINE        1013
#define IDC_SLABEL_ICQ                  1014
#define IDC_COMBO_ICQ                   1015
#define IDC_SLABEL_ICQ2                 1016
#define IDC_SLABEL_ICQ3                 1017
#define IDC_LIST                        1021
#define IDC_BUTTON_NEW                  1023
#define IDC_BUTTON_DELETE               1024
#define IDC_BUTTON_VARHELP              1026
#define IDC_CHECK_PLUGINENABLED         1029
#define IDC_CHECK_DISABLEPOPUPS         1030
#define IDC_CHECK_APPENDTEXT            1031
#define IDC_CHECK_MAXAGE                1032
#define IDC_EDIT_MAXAGE                 1033
#define IDC_STATIC_MAXAGE               1034
#define IDC_EDIT_APPENDTEXT             1035
#define IDC_BUTTON_LAUNCHINFO           1036
#define IDC_STATIC1                     1038
#define IDC_STATIC_CURDATA              1039
#define IDC_BUTTON_LIPATH               1040
#define IDC_LIST_LIDATA                 1041
#define IDC_CHECK_DISABLESOUNDS         1042
#define IDC_BUTTON_LIHELP               1042
#define IDC_STATIC_EXPL                 1044
#define IDC_BUTTON_PREVIEW              1046
#define IDC_CHECK_CHECKDATA             1047
#define IDAPPLY                         1049
#define IDC_LIST2                       1051
#define IDC_PROCESSLIST                 1051
#define IDC_PROTOIGNORELIST             1051
#define IDC_PROTOLIST                   1051
#define IDC_GROUPNAME                   1053
#define IDC_STATIC2                     1054
#define IDC_STATUS                      1055
#define IDC_STATUSMSG                   1056
#define IDC_STATIC3                     1057
#define IDC_SETBACK                     1058
#define IDC_POPUPNOTIFY                 1059
#define IDC_DISABLEPOPUPS               1060
#define IDC_DISABLESOUNDS               1061
#define IDC_ONLYFROMONLINE              1062
#define IDC_NEWPROC                     1063
#define IDC_DELPROC                     1064
#define IDC_APPLYPROC                   1065
#define IDC_PROCEDITFRAME               1066
#define IDC_EDIT_PROCNAME               1067
#define IDC_EDIT_APPNAME                1068
#define IDC_BUTTON_IMPORT               1070
#define IDC_CHECK_ALWAYSGLOBAL          1071
#define IDC_CHECK_SETSTATUS             1072
#define IDC_EDIT_ACTDELAY               1076
#define IDC_EDIT_DEACTDELAY             1077
#define IDC_STATIC_ACTDELAY             1078
#define IDC_STATIC_DEACTDELAY           1079
#define IDC_BUTTON_DELAYHELP            1081

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1082
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
