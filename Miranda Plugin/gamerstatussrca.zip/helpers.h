#include "common.h"

void popup(char*,char*);
void popup(char*,const char*, ...);

// indexed
BOOL GetDBString(char*,char*,const int);
BOOL GetDBString(char*,char*,int,int,char*);
char GetDBByte(char*,int,char);
int GetDBWord(char*,int,int);
void SetDBString(char*,int,const char*);
void SetDBWord(char*,int,int);
void SetDBByte(char*,int,char);
void DBDel(char*,int);

// unindexed
char GetDBByte(char*,char);
int GetDBWord(char*,int);
void SetDBWord(char*,int);
void SetDBByte(char*,char);
void SetDBString(char*,char*);
void DBDel(char*);

bool GetCheckVal(HWND,int);

double FileAge(char*);
void replace(char*,const char*,const char*);
BOOL GetClipboardString(char*,int);

void TextBox(const char*, ...);
void deleteProcGroup(int);
void cutExtension(char*,char*);

void setProtoStatus (const char*,int,char*);