// processGroupClass.h: Schnittstelle f�r die Klasse processGroupClass.
//
//////////////////////////////////////////////////////////////////////

#ifndef PROCESSGROUPCLASS_H_INCLUDED
#define PROCESSGROUPCLASS_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "common.h"
class awayProcessClass; // foreward
class BitArrayClass;

class processGroupClass  
{
private:
	int index;
	int litem;
	HWND hProcGroupList;
	BOOL DBSettingsLoaded;
	char *groupName;

	vector<string> processNames;
	vector<string> appNames;

public:
	processGroupClass();
	processGroupClass(int,BOOL);
	processGroupClass(int,char*,char*,char*,char*,unsigned int,int);
	processGroupClass(int,char*,char*[],char*[],int,char*,unsigned int,int);
	virtual ~processGroupClass();
	void init (char*,char*);

	int awayStatus;
	char *awayMessage;
	BitArrayClass<int> options;

	unsigned char activationDelay () { return this->options.getRange (activationDelay_start, activationDelay_end); }
	unsigned char deactivationDelay () { return this->options.getRange (deactivationDelay_start, deactivationDelay_end); }

	// methods
	int processLookUp(string*);

	BOOL loadBasicData();
	BOOL loadDBSettings();
	BOOL saveDBSettings();
	BOOL freeDBSettings();
	void deleteDBSettings();
	void changeIndex(int);
//	processClass *getProcess(processClass*,int);
	processClass getProcess(int);
//	void getAppName(string*,int);

	int setListItem(HWND);  // returns the item-id
	BOOL removeListItem();
//	void readdListItem();

	void resetDialogVars();
	int exportPropertyDlg(HWND);
	void importPropertyDlg(HWND);

	void importOldSettings();
	void deleteOldSettings();

	void debugpopup();
};

#endif // PROCESSGROUPCLASS_H_INCLUDED
