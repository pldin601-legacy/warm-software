#ifndef DEFINES_H_INCLUDED
#define DEFINES_H_INCLUDED

#define WIN32_LEAN_AND_MEAN

#define PLUGIN_VERSION PLUGIN_MAKE_VERSION(1,0,0,4)

#define maxStatusMsgLen 2048
#define maxProcessLen 256
#define maxGamesCount 256
#define maxLaunchInfo 32

#define defaultOptionsStorage 43


#define MS_AWAYSYS_SETSTATUSMODE "AwaySys/SetStatusMode"
#define MS_AWAYSYS_IGNORENEXT "AwaySys/IgnoreNextStatusChange"
#define MS_SS_GETPROFILE "StartupStatus/GetProfile"

#define ListView_SetCheckState(hwndLV, i, val) \
   ((((UINT)(SNDMSG((hwndLV), LVM_SETITEMSTATE, (WPARAM)i, LVIS_STATEIMAGEMASK))) << 12) -1)



#define strYes Translate("Yes")
#define strNo Translate("No")
#define strProcess Translate("Process")
#define strName Translate("Name")
#define strKey Translate("Key")
#define strValue Translate("Value")
#define strPreview Translate("Preview")
#define strFileNotFound Translate("FILE NOT FOUND")
#define strFileFound Translate("FILE FOUND, AGE: %i min")
#define strGroupName Translate("Group name")
#define strCount Translate("Count")
#define strStatus Translate("Status")
#define strSetBack Translate("Set back")
#define strPopup Translate("Popup")
#define strOnlyOnline Translate("Only online")
#define strDisablePopups Translate("Disable pop-ups")
#define strDisableSounds Translate("Disable sounds")

#define strConfirmProcGroupDel Translate("Are you sure that you want to delete this process-group?\n\nNOTE: The deletion will take effect immediately!")
#define strConfirmDelete Translate("Delete?")
#define strTextfiles Translate("Textfiles")
#define strAllFiles Translate("All Files")
#define strSelectInfoFile Translate("Select LaunchInfo.txt")

#define strConfirmImport Translate("The new gamerStatus plugin has found settings of a former version.\nThese settings are not compatible with the new version.\nDo you want to import these settings to further use them?")
#define strConfirmImport1 Translate("Import old gamerStatus settings?")
#define strOneGroupImport Translate("gamerStatus settings are now structured in groups,\nwhich have the same settings and away-message for several games/processes.\nDo you want to import all games/processes into ONE group instead of several groups for each game/process?\n\nNOTE: All away-messages but one will be lost and you'll have to correct the settings in the options.")
#define strOneGroupImport1 Translate("import gamerStatus settings into ONE group?")
#define strConfirmOldSettingsDel Translate("Do you want to delete the old settings?,\nyou won't be able to use them again if you go back to an older version of gamerStatus!\n\nNOTE: The old settings are totally independent from the new settings!")
#define strConfirmOldSettingsDel1 Translate("Delete old gamerStatus settings?")
#define strInitError Translate("GamerStatus Plugin encountered a problem. Processlist stuff probably won't work.\nPlease contact the author at mistag@baze.de, if you want this problem to be fixed.\n\n(Error msg: enumProcs init failed! Return value: %i)")

#define strVarHelp Translate("%exename%\tProcess name that's running (bla.exe)\n%appname%\tUser-defined name of the running process\n%statdesc%\tDescription of the status that is set (NA, DND, etc.)\n%clipboard%\tContent of the clipboard (if available as text)\n%launchinfo%\tUser-defined string from the LaunchInfo-options (if available)\n\nIf AwaySys plugin v0.2.7.8+ is installed, you can also use its variables.")
#define strVarHelp1 Translate("GamerStatus variables")
#define strLiHelp Translate("LaunchInfo.txt is a file that's created by The All-Seeing Eye (www.udpsoft.com/eye)\nor GameSpy (www.gamespy.com) and contains information about the game server you connect on.\n\nThis data can be used in this dialog, once set a correct LaunchInfo.txt path,\nyou can see all the data it contains on the right side of the dialog and insert them\ninto your custom %launchinfo% variable, which can be used in every status-message of gamerStatus.")
#define strLiHelp1 Translate("LaunchInfo - What's this?")
#define strDelayHelp Translate("Range: 0 (disabled) - 31\nIf a delay is activated (>0), gamerStatus waits before activating if a program is detected running.\nThis is helpful to avoid often status-changes if a program is only running for a short time.\nThe deactivation-delay is helpful if a program terminates and starts again after a short time.\n\nNOTE: The format is NOT in seconds, but in ticks:\nThe length of a tick is specified by the timer interval in the main options menu.")
#define strDelayHelp1 Translate("Help on delays")

/////////////
// DIALOGS //
/////////////
#define strEditing Translate("editing: %s")
#define strEditingNewProc Translate("editing: New process")
#define strAdd Translate("Add")
#define strApply Translate("Apply")



/////////////////
// POPUP TEXTS //
/////////////////
#define POPUP_TITLE					"GamerStatus"
#define POPUP_ACTIVATED				Translate("[b]%s[/b] activated")
#define POPUP_DETECTED				Translate("[b]%s[/b] detected running")
#define POPUP_DETECTED_DELAY		Translate("[b]%s[/b] detected running, delay: %is")
#define POPUP_TERMINATED			Translate("[b]%s[/b] terminated")
#define POPUP_TERMINATED_DELAY		Translate("[b]%s[/b] terminated, delay: %is")
#define POPUP_CHANGE				Translate("Changed to [b]%s[/b]")
#define POPUP_DISABLE				Translate("[b]%s[/b] disabled")
#define POPUP_DISABLEPROTO			Translate("Disabled status-control for [b]%s[/b]")
#define POPUP_RESET					Translate("[b]Back[/b] to normal")
#define POPUP_INFOFILEOPENERROR		Translate("LaunchInfo.txt could [b]not[/b] be [b]opened[/b]")



enum {
	setStatusBack,
	popupNotify,
	onlyFromOnline,
	disablePopups,
	disableSounds,
	setStatus,
	activationDelay_start,
	activationDelay_end = 10,
	deactivationDelay_start,
	deactivationDelay_end = 15
};

enum {
	alwaysGlobal,
	timerInterval_start,
	timerInterval_end = 5
};


//////////////////////
// AWAYPROC DB KEYS //
//////////////////////
#define awayProcActive "_awayProcActive"
#define awayProcIgnored "_awayProcIgnored"
#define awayProcOptions "_awayProcOptions"
#define awayProcOldStatus "_awayProcOldStatus"
#define awayProcProtoCount "_awayProcProtoCount"
#define awayProcProtoName "_awayProcProtoName%i"
#define awayProcProtoStatus "_awayProcProtoStatus%i"


#endif // DEFINES_H_INCLUDED
