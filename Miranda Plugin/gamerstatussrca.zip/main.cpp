/*
Miranda plugin template, originally by Richard Hughes
http://www.miranda-im.org/
*/
#include "common.h"
#include "EnumProcs.h"
#include "options.h"
#include "main.h"
//#include <crtdbg.h>

vector<processGroupClass> cfgGames;
awayProcessClass awayProcess;

BitArrayClass<int> cfgMainOptions;

vector<processClass> runningProcs;

HINSTANCE hInst;
PLUGINLINK *pluginLink;
char *pluginid="gamerStatusPlugin";

//BOOL cfgPluginEnabled=TRUE;
//unsigned char cfgTimerInterval=5;

UINT_PTR timerId=0;

PLUGININFO pluginInfo={
	sizeof(PLUGININFO),
	"GamerStatus plugin",
	PLUGIN_VERSION,
	"GamerStatus checks if one of the configured games/programs is running and changes Miranda's status accordingly.",
	"mistag",
	"mistag@baze.de",
	"� 2004 mistag",
	"http://www.miranda-im.org/",
	0,		//not transient
	0		//doesn't replace anything built-in
};

void check_version (int,int);

// rebase info (by disq):
// AKH 1+10+14 = 25 = 0x19
// 0x19010000

//static HANDLE hEventOptInitialise;

void saveProcGroupCount() {
	DBWriteContactSettingDword(NULL, pluginid, "processGroupCount", cfgGames.size());
	return;
}



static int MessageOptInit(WPARAM wParam, LPARAM lParam)
{
	OPTIONSDIALOGPAGE odp;
	ZeroMemory(&odp, sizeof(odp));
	odp.cbSize      = sizeof(odp);
	odp.position    = 910000000;
	odp.hInstance   = hInst;
	odp.pszTemplate = MAKEINTRESOURCE(IDD_OPT_CFG); //resource
	odp.pszTitle    = "GamerStatus";
	odp.pszGroup    = "Status";
	odp.pfnDlgProc  = mainOptionsDlg;

	CallService(MS_OPT_ADDPAGE, wParam, (LPARAM)&odp);

	return 0;
}

bool findRunningProcess (processClass *cProcess, bool tick) {
	for (int j=0; j<runningProcs.size(); j++)
		if (runningProcs[j] == cProcess) {
			if (tick) runningProcs[j].tick();
			return true;
		}
	return false;
}

bool activateRunningProcess () {
	if (runningProcs.empty()) return false;

	for (vector<processClass>::iterator j=runningProcs.begin(); j!=runningProcs.end(); j++) {
		if (j->getTickCount() >= j->procGroup->activationDelay())
			if (awayProcess.activate (*j, awayProcess.isActive))
				return true;
	}
	return false;
}

BOOL CALLBACK MyProcessEnumerator(DWORD dwPID, WORD wTask, LPCSTR szProcess, LPARAM lParam) {
	int i, procIndex;
	string cProcName(szProcess);

	for(i=0;i<cfgGames.size();i++) {
		procIndex = cfgGames[i].processLookUp(&cProcName);
		if (procIndex != -1) {
			processClass cProcess(cfgGames[i].getProcess(procIndex)); //processClass(cfgGames[i], cfgGames[i].processNames[procIndex]);
//			popup("found", (char*)cProcess.exename.c_str());

			if (!findRunningProcess(&cProcess, true)) {
				if (cProcess == awayProcess.awayProc) {
					awayProcess.awayProc.resetTickCount();
			} else {
					if (cProcess.procGroup->activationDelay() > 0 && cProcess.procGroup->options[popupNotify])
						popup (POPUP_TITLE, POPUP_DETECTED_DELAY, (char*)cProcess.appname.c_str(), cProcess.procGroup->activationDelay()*cfgTimerInterval);
					if (!awayProcess.protoMgr.perform(NULL,NULL,cProcess.procGroup->options[onlyFromOnline],NULL,false))
						continue;
				}

				runningProcs.push_back(processClass(cProcess));
			}
			break;
		}
	}
	return TRUE; // continue search
}

void CALLBACK timerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
//	if (!cfgPluginEnabled) return;
	if (awayProcess.protoMgr.isStatus(ID_STATUS_OFFLINE, false))
		return; // quit if all protos are offline

	EnumProcs((PROCENUMPROC)MyProcessEnumerator, 0); // check processes

	vector<processClass>::iterator i=runningProcs.begin();
	while (i != runningProcs.end())
		if (i->runFlag) {
			i->runFlag = false;
			i++;
		} else {
//			popup("deleting", i->exename.c_str());
			runningProcs.erase (i);
		}


	if (awayProcess.isActive || awayProcess.isIgnored) {
		if (!findRunningProcess(&awayProcess.awayProc, false)) { // process not running anymore
			awayProcess.awayProc.tick();
//			popup ("deactivate", "%i / %i", awayProcess.awayProc.getTickCount(), awayProcess.awayProc.procGroup->deactivationDelay);
			if (awayProcess.awayProc.getTickCount() > awayProcess.awayProc.procGroup->deactivationDelay()) {
				if (!activateRunningProcess()) { // try to activate another running process
					awayProcess.reset ((awayProcess.isActive)?POPUP_RESET:"",true);
				}
			} else if (awayProcess.awayProc.getTickCount() == 1) {
				awayProcess.notify (POPUP_TERMINATED_DELAY, (char*)awayProcess.awayProc.appname.c_str(), awayProcess.awayProc.procGroup->deactivationDelay()*cfgTimerInterval);
			}
		}
	} else {
		activateRunningProcess();
	}

	return;
}

bool deleteOldSettings (int tmpProcCount) {
	if (MessageBox(NULL, strConfirmOldSettingsDel, strConfirmOldSettingsDel1, MB_YESNO) == IDNO) return false;

	char *keys[] = {"game%i", "awayMessage%i", "statusBack%i", "popupNotify%i", "onlyFromOnline%i", "disablePopups%i", "disableSounds%i", "awayStatus%i"};
	int i, j;
	DBDel ("gamesCount");
	DBDel ("launchInfo");
	for (i=0; i<tmpProcCount; i++)
		for (j=0; j<sizeof(keys)/sizeof(char*); j++)
			DBDel (keys[j], i);
	return true;
}

void loadOldOptions (BitArrayClass<int> *options, int i) {
	char *keys[] = {"statusBack%i", "popupNotify%i", "onlyFromOnline%i", "disablePopups%i", "disableSounds%i"};
	for (int j=0; j<sizeof(keys)/sizeof(char*); j++)
		options->setBit (j, GetDBByte(keys[j], i, options[j]));
	return;
}

bool importOldSettings () {
	int i, tmpProcCount = DBGetContactSettingDword(NULL, pluginid, "gamesCount", 0);

	if (tmpProcCount <= 0) return false; // no old settings found
	if (MessageBox(NULL, strConfirmImport, strConfirmImport1, MB_YESNO) == IDNO) {
		deleteOldSettings(tmpProcCount);
		return false;
	}
	bool oneGroup = (tmpProcCount == 1);
	if (!oneGroup) oneGroup = (MessageBox(NULL, strOneGroupImport, strOneGroupImport1, MB_YESNO) == IDYES);

	char awayMsg[maxStatusMsgLen];
	BitArrayClass<int> options(defaultOptionsStorage);
	unsigned int awayStatus;

	if (oneGroup) {
		char *exenames[64];
		char *appnames[64];

		GetDBString(awayMsg, "awayMessage0", maxStatusMsgLen);
		awayStatus = GetDBWord("awayStatus%i", 0, ID_STATUS_OCCUPIED);

		loadOldOptions (&options, 0);

		for (i=0; i<tmpProcCount; i++) {
			exenames[i] = new char[64]; // isn't it a workaround? ^^
			appnames[i] = new char[64]; // ''
			GetDBString(exenames[i], "game%i", i, 64, "");
			cutExtension(appnames[i], exenames[i]);
		}
		cfgGames.push_back(processGroupClass(cfgGames.size(), "IMPORTED", exenames, appnames, tmpProcCount, awayMsg, awayStatus, options.getStorage()));
		for (i=0; i<tmpProcCount; i++) {
			delete[] exenames[i];
			delete[] appnames[i];
		}

	} else {
		char *exename = new char[64];
		char *appname = new char[64];

		for (i=0; i<tmpProcCount; i++) {
			GetDBString(exename, "game%i", i, 256, "");
			cutExtension(appname, exename);
			GetDBString(awayMsg, "awayMessage%i", i, maxStatusMsgLen, "I'm occupied...");
			awayStatus = GetDBWord("awayStatus%i", i, ID_STATUS_OCCUPIED);

			loadOldOptions (&options, i);

			cfgGames.push_back(processGroupClass(cfgGames.size(), exename, exename, appname, awayMsg, awayStatus, options.getStorage()));
		}
		delete[] exename;
		delete[] appname;
	}

	strcpy(awayMsg, "");
	GetDBString(awayMsg, "launchInfo", sizeof(awayMsg));
	if (awayMsg != "") SetDBString("infoFilePath%i", 0, awayMsg);

	deleteOldSettings(tmpProcCount);

	return true;
}

int userStatusChange (WPARAM wParam, LPARAM lParam) {
	return awayProcess.protoMgr.userStatusChange((char*)lParam, (int)wParam, &awayProcess);
}

int beforeShutdown (WPARAM wParam, LPARAM lParam) {
	awayProcess.reset("",true);
	return 0;
}

int MainInit (WPARAM wparam, LPARAM lparam) {
	int i = initEnumProcs(), lastVersion;

	if (i!=1) TextBox(strInitError, i);

	//hEventOptInitialise = HookEvent(ME_OPT_INITIALISE, MessageOptInit);
	HookEvent(ME_OPT_INITIALISE, MessageOptInit);
	HookEvent(ME_SYSTEM_PRESHUTDOWN, beforeShutdown);
	HookEvent(ME_CLIST_STATUSMODECHANGE, userStatusChange);

	int tmpProcCount = DBGetContactSettingDword(NULL, pluginid, "processGroupCount", -1);

	if ((lastVersion=GetDBWord("version",0)) < PLUGIN_VERSION)
		if (!importOldSettings() && tmpProcCount != -1)
			check_version (lastVersion, tmpProcCount);
	SetDBWord ("version", PLUGIN_VERSION);

	cfgMainOptions.setStorage(min(30,max(1,GetDBWord("cfgMainOptions", NULL))));

	if (tmpProcCount==-1) { // load defaults

		char *defProc0[]=	{"quake3.exe",	"hl.exe",			"bf1942.exe",		"ut2004.exe",				"war3.exe"};
		char *defApp0[]=	{"Quake 3",		"Half-Life / mod",	"Battlefield 1942",	"Unreal Tournament 2004",	"Warcraft 3"};
		char *defMsg0 = "I'm playing %appname%\r\nand therefore not going to answer soon...";
		cfgGames.push_back(processGroupClass (0, "Games", defProc0, defApp0, 5, defMsg0, ID_STATUS_OCCUPIED, defaultOptionsStorage));

		char *defProc1[]=	{"wmplayer.exe",			"mplayer.exe",	"zplayer.exe"};
		char *defApp1[]=	{"Windows Media Player",	"MPlayer",		"Zoom Player"};
		char *defMsg1= "Watchin' a movie\r\ntry again later...";
		cfgGames.push_back(processGroupClass (1, "Media players", defProc1, defApp1, 3, defMsg1, ID_STATUS_OCCUPIED, defaultOptionsStorage));

	} else {
		if (tmpProcCount>=maxGamesCount) tmpProcCount=maxGamesCount-1;
		for(i=0;i<tmpProcCount;i++) {
			try {
				cfgGames.push_back(processGroupClass (i,TRUE));
			} catch ( const char* ) {
				deleteProcGroup(i);
			}
		}
	}
	saveProcGroupCount();

	timerId = SetTimer(NULL, 0, cfgTimerInterval*1000, (TIMERPROC)timerProc);

	awayProcess.protoMgr.load();
	if (awayProcess.loadAwayInfo())
		awayProcess.reset("",true); // !ServiceExists(MS_SS_GETPROFILE) don't change status if startup-status is installed 

	return 0;
}

void check_version (int lastVersion, int tmpProcCount) {
	switch (lastVersion) {
		case 0: {
			int tmp = GetDBWord("timerInterval", 5);
			BitArrayClass<int> tmpOptions (GetDBWord("cfgMainOptions", 0));
			DBDel ("timerInterval");
			tmpOptions.setRange (timerInterval_start, timerInterval_end, tmp);
			SetDBWord("cfgMainOptions", tmpOptions.getStorage());
			
			for (int i=0; i<tmpProcCount; i++)
				if ((tmp=GetDBWord("options%i",i,-1)) != -1) {
					tmpOptions.setStorage (tmp);
					tmpOptions.setBit (setStatus, true);
					SetDBWord("options%i", i, tmpOptions.getStorage());
				}
		}
	};
	return;
}

extern "C" BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	hInst=hinstDLL;
	return TRUE;
}

extern "C" __declspec(dllexport) PLUGININFO* MirandaPluginInfo(DWORD mirandaVersion)
{
	return &pluginInfo;
}

extern "C" int __declspec(dllexport) Load(PLUGINLINK *link)
{
	pluginLink=link;
	HookEvent(ME_SYSTEM_MODULESLOADED, MainInit);
	return 0;
}

extern "C" int __declspec(dllexport) Unload(void) {
	for (int i=0; i<cfgGames.size(); i++) cfgGames[i].freeDBSettings ();
	cfgGames.clear ();
	runningProcs.clear ();
	shutdownEnumProcs ();
	KillTimer (NULL, timerId);
	return 0;
}

extern "C" int __declspec(dllexport) UninstallEx(PLUGINUNINSTALLPARAMS* ppup) {
	// Delete Files
	const char* apszFiles[] = {"readme_gamerstatus.txt", "translation_gamerstatus.txt", NULL};
	PUIRemoveFilesInDirectory(ppup->pszPluginsPath, apszFiles);	// Delete documentation in "Plugins" directory
	PUIRemoveFilesInDirectory(ppup->pszDocsPath, apszFiles);	// Delete documentation in "Docs" directory

	// Delete Settings
	if(ppup->bDoDeleteSettings && ppup->bIsMirandaRunning) 
		PUIRemoveDbModule(pluginid); // Remove plugin's module
	
	return 0;
}