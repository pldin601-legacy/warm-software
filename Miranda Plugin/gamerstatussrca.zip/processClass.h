// processClass.h: Schnittstelle f�r die Klasse processClass.
//
//////////////////////////////////////////////////////////////////////

#ifndef PROCESSCLASS_INCLUDED
#define PROCESSCLASS_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "common.h"
class processGroupClass;

class processClass {
private:
	int tickCount;
	bool hasValue;

public:
	processClass () : tickCount(0), hasValue(FALSE), procGroup(NULL), runFlag(true) {}
	processClass (processGroupClass *pG, string exe, string app) : tickCount(0), hasValue(TRUE), procGroup(pG), exename(exe), appname(app), runFlag(true) {}
	processClass (processGroupClass *pG, string exe) : tickCount(0), hasValue(TRUE), procGroup(pG), exename(exe), runFlag(true) {}
	virtual ~processClass () { this->clear(); }

	processGroupClass *procGroup;
//	int processIndex;
	string exename;
	string appname;
	bool runFlag;

	operator bool() const { return this->hasValue; }
	operator= (const processClass *other) { this->copy(other); return *this; }
	operator== (const processClass *other) { return (!this->hasValue)?FALSE:(this->procGroup == other->procGroup && this->exename.compare(other->exename) == 0); }
	operator== (const processClass other) { return (!this->hasValue)?FALSE:(this->procGroup == other.procGroup && this->exename.compare(other.exename) == 0); }

	void copy (const processClass *proc) {
		this->clear();
		this->hasValue = TRUE;
		this->procGroup = proc->procGroup;
		this->exename = proc->exename;
		this->appname = proc->appname;
		return;
	}

	void copy (const processClass proc) {
		this->clear();
		this->hasValue = TRUE;
		this->procGroup = proc.procGroup;
		this->exename = proc.exename;
		this->appname = proc.appname;
		return;
	}

	void clear() {
		if (!this->hasValue) return;
		this->hasValue = FALSE;
		this->tickCount = 0;
		this->procGroup = NULL;
		this->exename.erase();
		this->appname.erase();
	}

	void tick () { this->tickCount++; this->runFlag = true; return; }
	int getTickCount () { return this->tickCount; }
	void resetTickCount () { this->tickCount = 0; return; }
};
/*
class processClass_t : processClass {
private:
	int tickCount;
public:
	processClass_t () : processClass() {}
	processClass_t (processClass pC) : processClass(pC), tickCount(0) {}

	void tick () { this->tickCount++; }
	int getTickCount () { return this->tickCount; }

// work-around:
//	operator== (const processClass *other) { return (!this->hasValue)?FALSE:(this->procGroup == other->procGroup && this->exename.compare(other->exename) == 0); }
//	void copy (const processClass *proc) { processClass.copy(proc); }
};
*/
#endif // PROCESSCLASS_INCLUDED