// awayProcessClass.cpp: Implementierung der Klasse awayProcessClass.
//
//////////////////////////////////////////////////////////////////////

#include "common.h"

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

awayProcessClass::awayProcessClass() {}
awayProcessClass::~awayProcessClass() {}

BOOL awayProcessClass::activate(processClass proc, BOOL ProcessChanged) {
	if (this->isActive && !ProcessChanged) return FALSE;
	if (!this->protoMgr.perform(NULL,NULL,proc.procGroup->options[onlyFromOnline],NULL,false))
			return FALSE; // no action needed

//	popup("activating...", "exename = %s\nappname = %s\nhasValue = %i", proc.exename.c_str(), proc.appname.c_str(), proc.hasValue);
	this->awayProc.copy(proc);
	this->isIgnored = FALSE;
	this->isActive = TRUE;
	BOOL free = proc.procGroup->loadDBSettings();

	this->lastProcOptions.setBit(setStatus, proc.procGroup->options[setStatus]);
	if (proc.procGroup->options[setStatus]) {
		char tmp[maxStatusMsgLen];

		if (ProcessChanged) delete this->launchInfo;
		this->launchInfo = new launchInfoClass;

		strncpy(tmp, proc.procGroup->awayMessage, sizeof(tmp));

		this->GetStatusText(tmp);
		replace(tmp, "%exename%", proc.exename.c_str()); // ToDo: cut extension
		replace(tmp, "%appname%", proc.appname.c_str());
		replace(tmp, "%statdesc%", (char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, proc.procGroup->awayStatus, 0));

		// status backup & change
//		this->oldStatus = CallService(MS_CLIST_GETSTATUSMODE,0,0);
		this->protoMgr.perform (
				proc.procGroup->awayStatus, // statusMode
				tmp, // statusMsg
				proc.procGroup->options[onlyFromOnline], // onlyOnline?
				(ProcessChanged) ? NULL : &this->statusBackup, // backup statuses? .. if process changed, we want to keep the statuses-backup from before the awayProc got activated
				true // set statuses?
				);
//		if (this->oldStatus == ID_STATUS_OFFLINE || this->oldStatus == -1)
//			this->oldStatus = this->statusBackup.firstStatus();

		this->lastProcOptions.setBit(setStatusBack, proc.procGroup->options[setStatusBack]);
	} else this->lastProcOptions.setBit(setStatusBack, false);

	this->lastProcOptions.setBit(popupNotify, proc.procGroup->options[popupNotify]);
	this->notify ((ProcessChanged)?POPUP_CHANGE:POPUP_ACTIVATED, proc.appname.c_str());

	////////////////////////////////////
	// DISABLE/ENABLE SOUNDS & POPUPS //
	////////////////////////////////////
	if (ProcessChanged) {
		if (proc.procGroup->options[disablePopups] != this->lastProcOptions[disablePopups]) {
			this->lastProcOptions.setBit(disablePopups, proc.procGroup->options[disablePopups]);
			CallService(MS_POPUP_QUERY,2-proc.procGroup->options[disablePopups],0); // 2-proc.procGroup->disablePopups because PUQS_ENABLEPOPUPS = 1 and PUQS_DISABLEPOPUPS = 2
		}

		if (proc.procGroup->options[disableSounds] != this->lastProcOptions[disableSounds]) {
			this->lastProcOptions.setBit(disableSounds, proc.procGroup->options[disableSounds]);
			DBWriteContactSettingByte(NULL,"Skin","UseSound",(BYTE)proc.procGroup->options[disableSounds]);
		}
	} else {
		if (proc.procGroup->options[disablePopups] && CallService(MS_POPUP_QUERY, PUQS_GETSTATUS,0)) {
			CallService(MS_POPUP_QUERY, PUQS_DISABLEPOPUPS,0);
			this->lastProcOptions.setBit(disablePopups, TRUE);
		} else this->lastProcOptions.setBit(disablePopups, FALSE);

		if (proc.procGroup->options[disableSounds] && DBGetContactSettingByte(NULL,"Skin","UseSound",FALSE)) {
			DBWriteContactSettingByte(NULL,"Skin","UseSound",FALSE);
			this->lastProcOptions.setBit(disableSounds, TRUE);
		} else this->lastProcOptions.setBit(disableSounds, FALSE);
	}

	this->saveAwayInfo();
	if (free) proc.procGroup->freeDBSettings();

	return TRUE;
}


void awayProcessClass::deactivate(char *PopupText, BOOL SetStatus) {
	if (!this->isActive) return;
	this->isActive = FALSE;
	this->deleteAwayInfo();
	try {
		delete this->launchInfo;
	} catch (...) {}

	if (this->lastProcOptions[disablePopups]) CallService(MS_POPUP_QUERY, PUQS_ENABLEPOPUPS,0); // ENABLE POPUPS
	if (this->lastProcOptions[disableSounds]) DBWriteContactSettingByte(NULL,"Skin","UseSound",TRUE); // ENABLE SOUNDS
	if (PopupText != "")
		this->notify (PopupText, awayProc.appname.c_str()); // POPUP
	if (SetStatus && this->lastProcOptions[setStatusBack]) { // STATUS
		if (!this->protoMgr.ignoredProtos() || cfgMainOptions[alwaysGlobal])
			this->protoMgr.setGlobalStatus (this->statusBackup.firstStatus(), NULL);
/*
//		popup("old status", "%i", this->oldStatus);
		if (this->oldStatus == ID_STATUS_OFFLINE || this->oldStatus == 0) {
			if (this->statusBackup)
				this->protoMgr.setGlobalStatus (this->statusBackup.firstStatus(), NULL);
		} else {
			this->protoMgr.setGlobalStatus (this->oldStatus, NULL);
		}
*/

		this->statusBackup.restoreAll();
		this->statusBackup.clear();
	}
	return;
}
/*
int awayProcessClass::userStatusChange(WPARAM wparam, LPARAM lparam) {
	if (this->isActive && !this->ignoreStatusChange) {
		this->isIgnored = TRUE;
		this->deactivate(POPUP_DISABLE, FALSE);
	}
	return 0;
}
*/
/*
void awayProcessClass::checkStillRunning() {
//	popup(pluginid, "stillRunning: %i\npossProc: %i", this->isStillRunning, this->possibleProcess);
	if (!this->isStillRunning && (this->isActive || this->isIgnored)) { // awayProcess stopped running
		if (this->possibleProcess) {
			this->activate(this->possibleProcess, TRUE);
		} else {
			this->reset((this->isActive)?POPUP_RESET:"",true);
		}
	}
	this->possibleProcess.clear();
}
*/

void awayProcessClass::reset(char *popuptext, BOOL setStatus) {
	this->deactivate(popuptext, setStatus);
	this->isIgnored = FALSE;
	this->awayProc.clear();
}


void awayProcessClass::GetStatusText(char *StatusText) {
	char AppendText[maxStatusMsgLen];

	// APPEND TEXT
	strcpy(AppendText, "");
	if(this->launchInfo->fileAge != -1) // if file exists
		if(    DBGetContactSettingByte(NULL, pluginid, "bMaxAge", TRUE) == FALSE
			|| this->launchInfo->fileAge < DBGetContactSettingByte(NULL, pluginid, "MaxAge", TRUE)*60) // if file is not too old
			if(DBGetContactSettingByte(NULL, pluginid, "bAppendText", TRUE)) // if Appendtext is enabled
				GetDBString(AppendText, "AppendText", sizeof(AppendText));

	// LAUNCHINFO
	if (strstr(StatusText, "%li_") != NULL || strstr(AppendText, "%li_") != NULL) { // check if launchinfo-vars are in StatusText

			this->launchInfo->parseFile();
			this->launchInfo->replaceData(AppendText);

			if(    strstr(AppendText, "%li_") != NULL // if there are still %li_ vars
				&& DBGetContactSettingByte(NULL, pluginid, "bCheckData", TRUE) // liData-check on
			  ) strcpy(AppendText,"");
	}
	replace(StatusText, "%launchinfo%", AppendText);

	// CLIPBOARD
	if (strstr(StatusText, "%clipboard%") != NULL) { // check if %clipboard% is in StatusText
		char *tmp=NULL;
		if(!GetClipboardString(tmp, sizeof(tmp))) strcpy(tmp, "");
		replace(StatusText, "%clipboard%", tmp);
	}
}

void awayProcessClass::setPossibleProcess(processClass *proc) {
	this->possibleProcess.copy(proc);
}


BOOL awayProcessClass::isRunningProcess(processClass *proc) {
/*		popup(pluginid, "this->awayProc == proc : %i\naP.exename: %s\nproc.exename: %s",
			(this->awayProc == proc),
			this->awayProc.exename.c_str(),
			proc->exename.c_str()
		);
*/
	return this->awayProc == proc;
}

void awayProcessClass::saveAwayInfo() {
	if (!this->isActive) return;

	SetDBByte (awayProcActive, (byte)this->isActive);
	SetDBByte (awayProcIgnored, (byte)this->isIgnored);
	SetDBWord (awayProcOptions, this->lastProcOptions.getStorage());
//	SetDBWord (awayProcOldStatus, this->oldStatus);
	this->statusBackup.DBSave ();
}

void awayProcessClass::deleteAwayInfo() {
	DBDel (awayProcActive);
	DBDel (awayProcIgnored);
	DBDel (awayProcOptions);
//	DBDel (awayProcOldStatus);
	this->statusBackup.DBDelete ();
}

BOOL awayProcessClass::loadAwayInfo() {
	if (!GetDBByte(awayProcActive, FALSE)) return FALSE;

	this->isActive = TRUE;
	this->isIgnored = GetDBByte(awayProcIgnored, FALSE);
	this->lastProcOptions.setStorage (GetDBWord(awayProcOptions, NULL));
//	this->oldStatus = GetDBWord (awayProcOldStatus, ID_STATUS_ONLINE);
	this->statusBackup.DBLoad ();

	this->deleteAwayInfo();

	return TRUE;
}

void awayProcessClass::notify (char *text, const char *appname, int delay) {
	if (awayProc)
		if (awayProc.procGroup->options[popupNotify]) {
			popup(POPUP_TITLE, text, appname, delay);
		}
	return;
}