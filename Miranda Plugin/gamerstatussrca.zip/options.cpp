#include "common.h"
#include "options.h"
#include "main.h"

extern awayProcessClass awayProcess;

BOOL dlgChanged=FALSE;
int selectedProcClass=-1;
BOOL dlgChangedSkip=FALSE;
processGroupClass *openedProcGroup = NULL;
HWND hwndGroupList;
HWND hwndProcDlg;



// prototypes
void FileDialog(HWND,char*);
void SaveLaunchInfoOpts(HWND);
int dlgPopulateStatusCombo(HWND,int);
void dlgSelectLitem(int,HWND);
void dlgFill_liData(HWND,HWND,vector<StringPair>);
BOOL dlgSaveSettings(HWND,int);


int CALLBACK OptionsHelpDlgProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(uMsg == WM_INITDIALOG) {
		TranslateDialogDefault(hwndDlg);
		return TRUE;

	} else if(	uMsg == WM_COMMAND
			&&	HIWORD(wParam) == BN_CLICKED
			&&  (LOWORD(wParam)==IDOK || LOWORD(wParam)==IDCANCEL)) {
			DestroyWindow(hwndDlg);
			return TRUE;
	}

	return 0;
}

void editNewProc(int *cItem, HWND hwndDlg) {
	*cItem = -1;
	SetDlgItemText(hwndDlg, IDC_EDIT_PROCNAME, "");
	SetDlgItemText(hwndDlg, IDC_EDIT_APPNAME, "");
	SetDlgItemText(hwndDlg, IDC_PROCEDITFRAME, strEditingNewProc);
	SetDlgItemText(hwndDlg, IDC_APPLYPROC, strAdd);

	return;
}

void procGroup_checkBoxes (HWND hwndDlg) {
	bool checked = GetCheckVal(hwndDlg, IDC_CHECK_SETSTATUS);
	int i, controls[] = {IDC_SETBACK, IDC_ONLYFROMONLINE, IDC_STATUS, IDC_STATUSMSG, IDC_BUTTON_VARHELP, IDC_STATIC2, IDC_STATIC3};
	for (i=0; i<sizeof(controls)/sizeof(int); i++)
		EnableWindow (GetDlgItem(hwndDlg, controls[i]), checked);
	return;
}

int CALLBACK procGroupOptionsDlg(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WORD action = HIWORD (wParam);
	WORD control = LOWORD(wParam);
	static int cItem = -1;

	if(uMsg == WM_INITDIALOG) {
		LV_COLUMN lvc;
		char *column[]={strProcess, strName};
		char columnwidth[] = {80, 100};
		char i;
		HWND hwnd;

		hwndProcDlg = hwndDlg;

		hwnd=GetDlgItem(hwndDlg, IDC_STATUS);
		SendMessage(hwnd, CB_RESETCONTENT, 0, 0);
		dlgPopulateStatusCombo(hwnd, ID_STATUS_ONLINE);
		dlgPopulateStatusCombo(hwnd, ID_STATUS_AWAY);
		dlgPopulateStatusCombo(hwnd, ID_STATUS_OCCUPIED);
		dlgPopulateStatusCombo(hwnd, ID_STATUS_DND);
		dlgPopulateStatusCombo(hwnd, ID_STATUS_NA);
		dlgPopulateStatusCombo(hwnd, ID_STATUS_FREECHAT);
		dlgPopulateStatusCombo(hwnd, ID_STATUS_INVISIBLE);
		dlgPopulateStatusCombo(hwnd, ID_STATUS_OFFLINE);



		//////////////////////////
		// INIT IDC_PROCESSLIST //
		//////////////////////////
		hwnd = GetDlgItem(hwndDlg, IDC_PROCESSLIST);

		SendMessage(hwnd,LVM_SETEXTENDEDLISTVIEWSTYLE,0,LVS_EX_FULLROWSELECT); // Set style

		ZeroMemory(&lvc, sizeof(lvc)); // LV_COLUMN
		lvc.mask=LVCF_FMT|LVCF_WIDTH|LVCF_SUBITEM|LVCF_TEXT;
		lvc.fmt=LVCFMT_LEFT;

		for(i=0;i<=1;i++) {	
			lvc.iSubItem=i;
			lvc.pszText=column[i];
			lvc.cx = columnwidth[i];
			SendMessage(hwnd,LVM_INSERTCOLUMN,i,(LPARAM)&lvc);
		}

		TranslateDialogDefault(hwndDlg);
		return TRUE;


	} else if(uMsg == WM_COMMAND) {
/*		if (   !dlgChangedSkip
			&& (   (action==EN_UPDATE && (control==IDC_EDIT_PROCESS || control==IDC_EDIT_ICQ_ST))
				|| (action==CBN_SELCHANGE && control==IDC_STATUS)
				|| (action==BN_CLICKED && (   control==IDC_SETBACK
										   || control==IDC_ONLYFROMONLINE
										   || control==IDC_POPUPNOTIFY
										   || control==IDC_DISABLEPOPUPS
										   || control==IDC_DISABLESOUNDS
										  ))
			   )
			) {
			
			dlgChanged=TRUE;

		} else */
		if (action == BN_CLICKED) {
			if (control==IDOK || control==IDAPPLY) {
				if(openedProcGroup == NULL) { // new proc-entry
					cfgGames.push_back (processGroupClass((cfgGames.empty())?0:cfgGames.size(), FALSE));
					saveProcGroupCount();
					openedProcGroup = &cfgGames[cfgGames.size()-1];
//					openedProcGroup->debugpopup();

				}

				openedProcGroup->importPropertyDlg(hwndDlg);
				openedProcGroup->saveDBSettings();
				openedProcGroup->setListItem(hwndGroupList);
			}
			
			if (control==IDOK || control==IDCANCEL) {
				openedProcGroup = NULL;
				hwndProcDlg = NULL;
				DestroyWindow(hwndDlg);
			}

			if (control == IDC_APPLYPROC) {
				char tmp[maxProcessLen], tmp2[maxProcessLen];
				HWND hList = GetDlgItem(hwndDlg, IDC_PROCESSLIST);
				if (cItem == -1) {
					LV_ITEM lvi;

					ZeroMemory(&lvi, sizeof(lvi)); // LV_ITEM
					cItem = ListView_InsertItem(hList, &lvi);
				}

				GetDlgItemText(hwndDlg, IDC_EDIT_PROCNAME, tmp, sizeof(tmp));
				ListView_SetItemText(hList, cItem, 0, tmp);

				sprintf(tmp2, strEditing, tmp);
				SetDlgItemText(hwndDlg, IDC_PROCEDITFRAME, tmp2);

				GetDlgItemText(hwndDlg, IDC_EDIT_APPNAME, tmp, sizeof(tmp));
				ListView_SetItemText(hList, cItem, 1, tmp);

				editNewProc(&cItem, hwndDlg);

			} else if (control == IDC_NEWPROC) {
				editNewProc(&cItem, hwndDlg);

			} else if (control == IDC_DELPROC) {
				ListView_DeleteItem(GetDlgItem(hwndDlg, IDC_PROCESSLIST), SendMessage(GetDlgItem(hwndDlg, IDC_PROCESSLIST),LVM_GETNEXTITEM,-1,LVNI_FOCUSED));
				editNewProc(&cItem, hwndDlg);

			} else if (control == IDC_BUTTON_VARHELP) {
				MessageBox (NULL, strVarHelp, strVarHelp1, MB_ICONINFORMATION);

			} else if (control == IDC_CHECK_SETSTATUS) {
				procGroup_checkBoxes (hwndDlg);

			} else if (control==IDC_BUTTON_DELAYHELP) {
				MessageBox (hwndDlg, strDelayHelp, strDelayHelp1, MB_ICONINFORMATION);
			}
			return TRUE;
		}
	} else if(uMsg == WM_NOTIFY) {

		if(((NMHDR FAR *)lParam)->code == NM_CLICK) {
			HWND hList = GetDlgItem(hwndDlg, IDC_PROCESSLIST);
			char tmp[maxProcessLen], tmp2[maxProcessLen];

			cItem = ((LPNMITEMACTIVATE)lParam)->iItem;

			if (cItem != -1) {
				ListView_GetItemText(hList, cItem, 0, tmp, sizeof(tmp));
				SetDlgItemText(hwndDlg, IDC_EDIT_PROCNAME, tmp);

				sprintf(tmp2, strEditing, tmp);
				SetDlgItemText(hwndDlg, IDC_PROCEDITFRAME, tmp2);

				ListView_GetItemText(hList, cItem, 1, tmp, sizeof(tmp));
				SetDlgItemText(hwndDlg, IDC_EDIT_APPNAME, tmp);

				SetDlgItemText(hwndDlg, IDC_APPLYPROC, strApply);
			} else {
				editNewProc(&cItem, hwndDlg);
			}
		}
		return TRUE;
	}

	return 0;
}



int CALLBACK OptionsLaunchInfoProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	static infoFileClass *launchInfo = NULL;
	char tmp[maxStatusMsgLen];
	int i;

	switch (uMsg)
	{
		case WM_INITDIALOG:	{
			LV_COLUMN lvc;
			// LV_ITEM lvi;
			char *column[]={strKey, strValue};
			char columnwidth[2] = {80, 100};
			HWND hwnd;



			//////////////////////////
			// INIT IDC_LIST_LIDATA //
			//////////////////////////
			hwnd = GetDlgItem(hwndDlg, IDC_LIST_LIDATA);

			SendMessage(hwnd,LVM_SETEXTENDEDLISTVIEWSTYLE,0,LVS_EX_FULLROWSELECT); // Set style

			ZeroMemory(&lvc, sizeof(lvc)); // LV_COLUMN
			lvc.mask=LVCF_FMT|LVCF_WIDTH|LVCF_SUBITEM|LVCF_TEXT;
			lvc.fmt=LVCFMT_LEFT;

			for(i=0;i<=1;i++) {	
				lvc.iSubItem=i;
				lvc.pszText=column[i];
				lvc.cx = columnwidth[i];
				SendMessage(hwnd,LVM_INSERTCOLUMN,i,(LPARAM)&lvc);
			}


			///////////////////
			// LOAD CONTENTS //
			///////////////////

			// CHECKBOXES
			if(DBGetContactSettingByte(NULL, pluginid, "bAppendText", FALSE)) {
				SendMessage(GetDlgItem(hwndDlg, IDC_CHECK_APPENDTEXT), BM_SETCHECK, BST_CHECKED, 0);
			} else {
				EnableWindow(GetDlgItem(hwndDlg, IDC_CHECK_MAXAGE), FALSE);
				EnableWindow(GetDlgItem(hwndDlg, IDC_CHECK_CHECKDATA), FALSE);
				EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_MAXAGE), FALSE);
				EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_APPENDTEXT), FALSE);
			}

			if(DBGetContactSettingByte(NULL, pluginid, "bMaxAge", TRUE)) {
				SendMessage(GetDlgItem(hwndDlg, IDC_CHECK_MAXAGE), BM_SETCHECK, BST_CHECKED, 0);
			} else {
				EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_MAXAGE), FALSE);
			}

			if(DBGetContactSettingByte(NULL, pluginid, "bCheckData", TRUE)) {
				SendMessage(GetDlgItem(hwndDlg, IDC_CHECK_CHECKDATA), BM_SETCHECK, BST_CHECKED, 0);			
			}	

			// IDC_EDIT_LAUNCHINFO
			GetDBString(tmp, "infoFilePath0", sizeof(tmp));
			launchInfo = new launchInfoClass (0,tmp);
			SetDlgItemText(hwndDlg, IDC_EDIT_LAUNCHINFO, tmp);

			// IDC_EDIT_MAXAGE
			sprintf(tmp,"%i",DBGetContactSettingByte(NULL, pluginid, "MaxAge", 2));
			SetDlgItemText(hwndDlg,IDC_EDIT_MAXAGE,tmp);

			// IDC_EDIT_APPENDTEXT
			GetDBString(tmp, "AppendText", sizeof(tmp));
			if(strcmp(tmp,"")==0) strcpy(tmp, "IP: %li_ServerAddr%\r\nName: %li_ServerName%");
			SetDlgItemText(hwndDlg,IDC_EDIT_APPENDTEXT,tmp);



			TranslateDialogDefault(hwndDlg);
			return TRUE;
		}
		
		case WM_COMMAND: {
			switch(LOWORD(wParam)) {

				case IDOK:
					if(HIWORD(wParam) == BN_CLICKED) {
						SaveLaunchInfoOpts(hwndDlg);
						DestroyWindow(hwndDlg);
						return TRUE;
					} break;

				case IDCANCEL:
					if(HIWORD(wParam) == BN_CLICKED) {
						DestroyWindow(hwndDlg);
						return TRUE;
					} break;

				case IDC_BUTTON_PREVIEW:
					if(    HIWORD(wParam) == BN_CLICKED) {
//						&& GetDlgItemText(hwndDlg, IDC_EDIT_LAUNCHINFO, tmp, sizeof(tmp))) {
						
//						launchInfoClass launchInfo (tmp);

						if(launchInfo) {
							GetDlgItemText(hwndDlg, IDC_EDIT_APPENDTEXT, tmp, sizeof(tmp));
							launchInfo->replaceData(tmp);
							MessageBox(hwndDlg, tmp, strPreview, MB_OK);
						}
					} break;

				case IDC_EDIT_LAUNCHINFO: {
					if(HIWORD(wParam) == EN_CHANGE) {
//						if(GetDlgItemText(hwndDlg, IDC_EDIT_LAUNCHINFO, tmp, sizeof(tmp))) {

							HWND hwnd = GetDlgItem(hwndDlg, IDC_LIST_LIDATA);

							ListView_DeleteAllItems(hwnd);

							if (launchInfo == NULL) {
								TextBox ("failed initializing the temporary infoFileClass");
							} else if (!launchInfo) {
								SetDlgItemText(hwndDlg,IDC_STATIC_CURDATA,strFileNotFound);
								EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_PREVIEW), FALSE);
							} else { // FILE FOUND
								EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_PREVIEW), TRUE);
								if(launchInfo->parseFile()) {

									sprintf(tmp, strFileFound, (launchInfo->fileAge/60));
									SetDlgItemText(hwndDlg,IDC_STATIC_CURDATA,tmp);

									if(!launchInfo->fileData.empty()) // if parsing succeeded
										dlgFill_liData(hwndDlg, hwnd, launchInfo->fileData);
								}
							}
					}
				} break;

				case IDC_CHECK_APPENDTEXT:
					if(HIWORD(wParam) == BST_UNCHECKED) {
						tmp[0] = GetCheckVal(hwndDlg, IDC_CHECK_APPENDTEXT);
						EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_APPENDTEXT), tmp[0]);
						EnableWindow(GetDlgItem(hwndDlg, IDC_CHECK_MAXAGE), tmp[0]);
						EnableWindow(GetDlgItem(hwndDlg, IDC_CHECK_CHECKDATA), tmp[0]);
						if(tmp[0] == TRUE) tmp[0] = GetCheckVal(hwndDlg, IDC_CHECK_MAXAGE);
						EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_MAXAGE), tmp[0]);
					} break;

				case IDC_CHECK_MAXAGE:
					if(HIWORD(wParam) == BST_UNCHECKED) {
						EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_MAXAGE), GetCheckVal(hwndDlg, IDC_CHECK_MAXAGE));
					} break;

				case IDC_BUTTON_LIPATH:
					if (HIWORD(wParam) == BN_CLICKED) {
						GetDlgItemText(hwndDlg, IDC_EDIT_LAUNCHINFO, tmp, sizeof(tmp));
						FileDialog(hwndDlg, tmp);
						// strcpy(tmp, "F:\\dev\\cpp\\_miranda\\_miranda_test\\Plugins\\LaunchInfo.txt");
						SetDlgItemText(hwndDlg, IDC_EDIT_LAUNCHINFO, tmp);
					} break;
				// ToDo: Doubleclick-event of the listview, which adds the clicked variable to IDC_EDIT_APPENDTEXT

				case IDC_BUTTON_LIHELP:
					MessageBox (NULL, strLiHelp, strLiHelp1, MB_ICONINFORMATION);
			}
		} break;

		case WM_NOTIFY:
		{
			NMHDR* nmhdr = (NMHDR FAR *)lParam;
			if (nmhdr->idFrom != 0 && nmhdr->idFrom != IDC_LIST_LIDATA) return TRUE;

			if (nmhdr->code == NM_DBLCLK) {
				int iItem = LPNMITEMACTIVATE(lParam)->iItem;

				char tmp[maxStatusMsgLen];
				GetDlgItemText(hwndDlg, IDC_EDIT_APPENDTEXT, tmp, maxStatusMsgLen);

				if (tmp[strlen(tmp)-1] != char(" ")) strcat (tmp, " ");
				string tmpVar ("%li_");
				tmpVar += launchInfo->getKey(iItem);
				tmpVar += string("%");
				strcat (tmp, tmpVar.c_str());

				SetDlgItemText(hwndDlg, IDC_EDIT_APPENDTEXT, tmp);
			}
		} break;

		case WM_DESTROY: {
			delete launchInfo;
		} break;
	}
	return 0;
}


BOOL getSelectedListItem(LPNMITEMACTIVATE lpnmitem, HWND hwndDlg) {
	LV_ITEM lvi;

	if (lpnmitem->hdr.idFrom != IDC_LIST) return FALSE;

	ZeroMemory(&lvi, sizeof(lvi)); // LV_ITEM
	lvi.iItem=lpnmitem->iItem;
	lvi.mask=LVIF_PARAM;
	lvi.iSubItem=0;
	if (!ListView_GetItem(GetDlgItem(hwndDlg, IDC_LIST), &lvi)) return FALSE; //error reading item

	// get responding processClass
	selectedProcClass=(int)lvi.lParam;

	return TRUE;
}


int CALLBACK mainOptionsDlg(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	int i;

	HWND hwnd;

	LV_COLUMN lvc;
//	LV_ITEM lvi;

	NMHDR* nmhdr = NULL;

	switch (uMsg) {
		case WM_INITDIALOG:
		{
			char *column[]={strGroupName, strCount, strStatus, strSetBack, strPopup, strOnlyOnline, strDisablePopups, strDisableSounds};
			int columnwidth[]={90, 50, 50, 50, 50, 50, 50, 50};

			hwndGroupList = GetDlgItem(hwndDlg, IDC_LIST);

			TranslateDialogDefault(hwndDlg);
			SetDlgItemInt(hwndDlg, IDC_EDIT_INTERVAL, cfgTimerInterval, TRUE);

//			SendMessage(GetDlgItem(hwndDlg, IDC_CHECK_PLUGINENABLED), BM_SETCHECK, cfgPluginEnabled?BST_CHECKED:BST_UNCHECKED, 0);

			// IDC_LIST (columns)
			hwnd=GetDlgItem(hwndDlg, IDC_LIST);
			ZeroMemory(&lvc, sizeof(lvc)); // LV_COLUMN
			lvc.mask=LVCF_FMT|LVCF_SUBITEM|LVCF_TEXT|LVCF_WIDTH;
			lvc.fmt=LVCFMT_LEFT;

			for(i=0; i<8; i++) {			
				lvc.iSubItem=i;
				lvc.pszText=column[i];
				lvc.cx=columnwidth[i];
				ListView_InsertColumn(hwnd, i, &lvc);
			}
			ListView_SetExtendedListViewStyle(hwnd, LVS_EX_FULLROWSELECT);
			ListView_DeleteAllItems(hwndGroupList);

			for(i=0;i<cfgGames.size();i++) {
				cfgGames[i].loadDBSettings();
//				MessageBox(NULL, cfgGames[i].awayMessage, cfgGames[i].processName, 0);
				cfgGames[i].setListItem(hwndGroupList);
			}

			hwnd = GetDlgItem(hwndDlg,IDC_PROTOLIST);

			ListView_SetExtendedListViewStyleEx(hwnd, LVS_EX_CHECKBOXES | LVS_EX_FULLROWSELECT, LVS_EX_CHECKBOXES | LVS_EX_FULLROWSELECT);
			awayProcess.protoMgr.exportList (hwnd);

			if (DBGetContactSettingDword(NULL, pluginid, "gamesCount", 0) <= 0)
				EnableWindow (GetDlgItem(hwndDlg, IDC_BUTTON_IMPORT),false);

			SendMessage(GetDlgItem(hwndDlg, IDC_CHECK_ALWAYSGLOBAL), BM_SETCHECK, cfgMainOptions[alwaysGlobal]?BST_CHECKED:BST_UNCHECKED, 0);

			return TRUE;
		}

		case WM_COMMAND:
		{
			WORD action=HIWORD (wParam);
			WORD control=LOWORD(wParam);
//			BOOL skip=dlgChangedSkip;

/*
			if (action==BN_CLICKED && control==IDC_BUTTON_SAVE && dlgChanged==TRUE) {
				int temp=selectedProcClass;
				if (dlgSaveSettings(hwndDlg, selectedProcClass)) {
					dlgSelectLitem(hwndDlg, temp);
					selectedProcClass=temp;
					dlgChangedSkip=FALSE;
					dlgChanged=FALSE;
					EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_SAVE), FALSE);
					EnableWindow(GetDlgItem(hwndDlg, IDC_BUTTON_NEW), TRUE);
				}
			}
*/
			if (action==BN_CLICKED && control==IDC_BUTTON_NEW) {
/*				if (dlgChanged==TRUE) {
	//				if (MessageBox(hwndDlg, Translate("Lose changes to this entry? (Click NO to cancel)"), Translate("Modified setting"), MB_YESNO|MB_ICONWARNING|MB_DEFBUTTON2|MB_APPLMODAL)==IDNO) return(TRUE);
					int i=MessageBox(hwndDlg, Translate("Save changes to this entry?"), Translate("Modified setting"), MB_YESNOCANCEL|MB_ICONWARNING|MB_DEFBUTTON1|MB_APPLMODAL);
					if (i==IDCANCEL) return(TRUE);
					if (i==IDYES) {
//						dlgSaveSettings(hwndDlg, selectedProcClass);
					}
				}
*/
				hwnd=CreateDialogParam(hInst, MAKEINTRESOURCE(IDD_OPT_PROCGROUP), hwndDlg, procGroupOptionsDlg, 0);
				if (hwnd!=NULL) ShowWindow(hwnd, SW_SHOW);
			}

			if (action==BN_CLICKED && control==IDC_BUTTON_DELETE && selectedProcClass != -1) {
				if (MessageBox(hwndDlg, strConfirmProcGroupDel, strConfirmDelete, MB_YESNO|MB_ICONWARNING|MB_DEFBUTTON2|MB_APPLMODAL)==IDYES) {
					deleteProcGroup(selectedProcClass);
				}
			}

			if (action==BN_CLICKED && control==IDC_BUTTON_LAUNCHINFO) {
				hwnd=CreateDialogParam(hInst, MAKEINTRESOURCE(IDD_OPT_LAUNCHINFO), hwndDlg, OptionsLaunchInfoProc, 0);
				if (hwnd!=NULL) ShowWindow(hwnd, SW_SHOW);
			}

			if ((HWND)lParam==GetFocus() && (action == EN_CHANGE || action == BST_UNCHECKED)) {
				SendMessage(GetParent(hwndDlg), PSM_CHANGED,0,0);
			}

			return TRUE;
		}
	}



	if (uMsg == WM_NOTIFY) {

		nmhdr = (NMHDR FAR *)lParam;

		if (nmhdr->idFrom == IDC_LIST) {
			switch (nmhdr->code) {
				case NM_CLICK: {
					LPNMITEMACTIVATE lpnmitem = (LPNMITEMACTIVATE) lParam;
					if(!getSelectedListItem(lpnmitem, hwndDlg)) return 0;
				} break;

				case NM_DBLCLK: {
					LPNMITEMACTIVATE lpnmitem = (LPNMITEMACTIVATE) lParam;
					
					if(!getSelectedListItem(lpnmitem, hwndDlg)) return 0;

					if (openedProcGroup != NULL) {
						int i = MessageBox(hwndDlg, Translate("Save changes to this entry?"), Translate("Modified settings"), MB_YESNOCANCEL|MB_ICONWARNING|MB_DEFBUTTON1|MB_APPLMODAL);
						if (i==IDCANCEL) return TRUE;
						if (i==IDYES) {
							openedProcGroup->importPropertyDlg(hwndProcDlg);
							openedProcGroup->saveDBSettings();
							openedProcGroup->setListItem(hwndGroupList);							
						}
					} else {
						CreateDialogParam(hInst, MAKEINTRESOURCE(IDD_OPT_PROCGROUP), hwndDlg, procGroupOptionsDlg, 0);
					}

					ShowWindow(hwndProcDlg, SW_SHOW);
					openedProcGroup = &cfgGames[selectedProcClass];
					openedProcGroup->loadDBSettings (); // workaround
					openedProcGroup->exportPropertyDlg(hwndProcDlg);
				} break;
			}
		} else if (nmhdr->idFrom == IDC_PROTOLIST && nmhdr->code == NM_CLICK && ((LPNMITEMACTIVATE)lParam)->iItem != -1) {
			SendMessage(GetParent(hwndDlg), PSM_CHANGED,0,0);
		}

		if (uMsg == WM_NOTIFY && (nmhdr->code == PSN_APPLY || nmhdr->code == PSN_KILLACTIVE)) { // save settings
			saveProcGroupCount();

//			cfgPluginEnabled=TRUE;
//			if (SendMessage(GetDlgItem(hwndDlg, IDC_CHECK_PLUGINENABLED), BM_GETCHECK, 0, 0)==BST_UNCHECKED) cfgPluginEnabled=FALSE;
//			DBWriteContactSettingByte(NULL, pluginid, "pluginEnabled", (byte)(cfgPluginEnabled?1:0));

			cfgMainOptions.setRange (timerInterval_start, timerInterval_end, min(30, max(1, GetDlgItemInt(hwndDlg, IDC_EDIT_INTERVAL, NULL, FALSE))));
			KillTimer(NULL, timerId);
			timerId = SetTimer(NULL, 0, cfgTimerInterval*1000, (TIMERPROC)timerProc);

			cfgMainOptions.setBit (alwaysGlobal, GetCheckVal(hwndDlg, IDC_CHECK_ALWAYSGLOBAL));
			SetDBWord ("cfgMainOptions", cfgMainOptions.getStorage());

			awayProcess.protoMgr.importList (GetDlgItem(hwndDlg, IDC_PROTOLIST));
			awayProcess.protoMgr.DBSave ();
		}

		if (uMsg == WM_DESTROY || (uMsg == WM_NOTIFY && (nmhdr->code == PSN_APPLY || nmhdr->code == PSN_KILLACTIVE || nmhdr->code == -12))) { // -12 = cancel
			hwndGroupList = NULL;
			for (i=0; i<cfgGames.size(); i++) {
				cfgGames[i].freeDBSettings();
				cfgGames[i].resetDialogVars();
			}
		}
	}

	return FALSE;
}



/*
void deleteSettings(int del, BOOL loadExtSettings) {
	cfgGames[del]->deleteDBSettings();
	cfgGamesCount--;

	if(loadExtSettings) cfgGames[cfgGamesCount]->loadDBSettings();
	cfgGames[cfgGamesCount]->deleteDBSettings();
	cfgGames[cfgGamesCount]->index = del;
	cfgGames[cfgGamesCount]->saveDBSettings();
	if(loadExtSettings) cfgGames[cfgGamesCount]->freeDBSettings();

	memcpy(&cfgGames[del], &cfgGames[cfgGamesCount], sizeof(cfgGames[del]));
}
*/

void dlgSelectLitem(int toSelect, HWND hwndList)
{
	ListView_SetItemState(hwndList, -1, 0, LVIS_SELECTED); // deselect all items
	SendMessage(hwndList, LVM_ENSUREVISIBLE, (WPARAM)toSelect, FALSE); // if item is far, scroll to it
	ListView_SetItemState(hwndList, toSelect, LVIS_SELECTED, LVIS_SELECTED); // select toSelect
	ListView_SetItemState(hwndList, toSelect, LVIS_FOCUSED, LVIS_FOCUSED); // optional
	ListView_SetItemState(hwndList, toSelect, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED);
}


void dlgFill_liData(HWND hwndDlg, HWND hwnd, vector<StringPair> liData)
{
	int i;
	LV_ITEM lvi;

	//  Setting properties Of Items:
	ZeroMemory(&lvi, sizeof(lvi));
	lvi.mask=LVIF_TEXT;   // Text Style
	lvi.cchTextMax = 256; // Max size of text

	
	for(i=0; i<liData.size(); i++) {    
		lvi.iItem=i; // choose item

		// insert key
		lvi.iSubItem=0; // Put in first column
		lvi.pszText = (char*)liData[i].key.c_str();
		SendMessage(hwnd, LVM_INSERTITEM, 0, (LPARAM)&lvi); // Send to the Listview

		// insert value
		lvi.iSubItem=1;
		lvi.pszText = (char*)liData[i].val.c_str();
		SendMessage(hwnd, LVM_SETITEM, 0, (LPARAM)&lvi); // Send to the Listview
	}

}

/*
void dlgSelectProcess(HWND hwndDlg, char *processName)
{
	HWND hwnd;
	int i, item;
	int itemCount;
	char tmp[maxProcessLen];
	strcpy(tmp, "");

	hwnd=GetDlgItem(hwndDlg, IDC_LIST);

	itemCount=ListView_GetItemCount(hwnd);
	item=-1;
	for(i=0;i<itemCount;i++) {
		ListView_GetItemText(hwnd, i, 0, tmp, 256);
		if (strncmp(tmp, cfgGames[selectedProcClass].processName, sizeof(tmp)) == 0) {
			item=i;
			break;
		}
	}
	if (item==-1) return;

	ListView_SetItemState(hwnd, item, LVIS_SELECTED|LVIS_FOCUSED, LVIS_SELECTED|LVIS_FOCUSED);
}
*/

/*
BOOL dlgSaveSettings(HWND hwndDlg, int selItem)
{
	HWND hwnd;
	int i, where;
	char tmp[maxProcessLen];

	where=selItem;
	if (selItem==-1) where=cfgGamesCount;

	GetDlgItemText(hwndDlg, IDC_EDIT_PROCESS, tmp, maxProcessLen);
	if (!strcmp(tmp, "")) {
		MessageBox(hwndDlg, Translate("You must enter a process name!"), Translate("Error"), MB_OK|MB_ICONSTOP);
		return(FALSE);
	}


	for(i=0;i<cfgGamesCount;i++) {
		if (!strncmp(tmp, cfgGames[i].processName, maxProcessLen)) {
			where=i;
			break;
		}
	}

	GetDlgItemText(hwndDlg, IDC_EDIT_PROCESS, cfgGames[where].processName, maxProcessLen);

	hwnd=GetDlgItem(hwndDlg, IDC_COMBO_ICQ);
	i=SendMessage(hwnd, CB_GETCURSEL, 0, 0);
	if (i==CB_ERR) i=0;
	i=SendMessage(hwnd, CB_GETITEMDATA, i, 0);
	if (i==CB_ERR) i=ID_STATUS_ONLINE;
	cfgGames[where].awayStatus=i;

	GetDlgItemText(hwndDlg, IDC_EDIT_ICQ_ST, cfgGames[where].awayMessage, sizeof(cfgGames[where].awayMessage));

	cfgGames[where].setStatusBack=GetCheckVal(hwndDlg, IDC_CHECK_ICQ_SETBACK);
	cfgGames[where].popupNotify=GetCheckVal(hwndDlg, IDC_CHECK_POPUPS);
	cfgGames[where].onlyFromOnline=GetCheckVal(hwndDlg, IDC_CHECK_ONLYFROMONLINE);
	cfgGames[where].disablePopups=GetCheckVal(hwndDlg, IDC_CHECK_DISABLEPOPUPS);
	cfgGames[where].disableSounds=GetCheckVal(hwndDlg, IDC_CHECK_DISABLESOUNDS);

	if (where==cfgGamesCount+1) cfgGamesCount++;

	return(TRUE);
}
*/


void SaveLaunchInfoOpts(HWND hwndDlg) {
	int MaxAge;
	char tmp[256];

	// IDC_EDIT_LAUNCHINFO
	GetDlgItemText(hwndDlg, IDC_EDIT_LAUNCHINFO, tmp, sizeof(tmp));
	SetDBString("infoFilePath0", tmp);

	// IDC_EDIT_MAXAGE
	MaxAge = GetDlgItemInt(hwndDlg, IDC_EDIT_MAXAGE, NULL, FALSE);
	if(MaxAge>255) MaxAge = 255;
	SetDBByte ("MaxAge", MaxAge);

	// IDC_EDIT_APPENDTEXT
	GetDlgItemText(hwndDlg, IDC_EDIT_APPENDTEXT, tmp, sizeof(tmp));
	SetDBString("AppendText", tmp);

	// CHECKBOXES
	SetDBByte("bAppendText", GetCheckVal(hwndDlg, IDC_CHECK_APPENDTEXT));
	SetDBByte("bMaxAge", GetCheckVal(hwndDlg, IDC_CHECK_MAXAGE));
	SetDBByte("bCheckData", GetCheckVal(hwndDlg, IDC_CHECK_CHECKDATA));
}


int dlgPopulateStatusCombo(HWND hwnd, int statusMode) {
	int i;

	i=SendMessage(hwnd, CB_ADDSTRING, 0, (LPARAM)(char *)CallService(MS_CLIST_GETSTATUSMODEDESCRIPTION, statusMode, 0));
	if (i!=CB_ERR && i!=CB_ERRSPACE) SendMessage(hwnd, CB_SETITEMDATA, i, statusMode);
	return(i);
}


void FileDialog(HWND hwndDlg, char *Path) {
	OPENFILENAME ofn;
	char filter[512], *pfilter;

	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hwndDlg;//GetParent(hwndDlg);
	ofn.hInstance = NULL;

	strcpy(filter,strTextfiles);
	strcat(filter," (*.txt)");
	pfilter=filter+strlen(filter)+1;
	strcpy(pfilter,"*.TXT");
	pfilter=pfilter+strlen(pfilter)+1;
	strcpy(pfilter,strAllFiles);
	strcat(pfilter," (*)");
	pfilter=pfilter+strlen(pfilter)+1;
	strcpy(pfilter,"*");
	pfilter=pfilter+strlen(pfilter)+1;
	*pfilter='\0';

	ofn.lpstrFilter = filter;
	ofn.lpstrFile = Path; // says: ofn.lpstrFile is a pointer (redirect) to Path, which is tmp at the caller and the GetOpenFileName uses this pointer (redirect) to write the lpstrFile into Path / tmp
	ofn.Flags = OFN_PATHMUSTEXIST|OFN_FILEMUSTEXIST;
	ofn.nMaxFile = MAX_PATH;
//	ofn.nMaxFileTitle = sizeof(Path);
//	ofn.lpstrDefExt = NULL;
	ofn.lpstrTitle = strSelectInfoFile;

	GetOpenFileName(&ofn);
}