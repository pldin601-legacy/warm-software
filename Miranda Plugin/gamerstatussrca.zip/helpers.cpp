#include "common.h"
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
extern HWND hwndGroupList;

void popup(char *title, char *text) {
	POPUPDATAEX ppd = { 0 };

	if (!ServiceExists(MS_POPUP_ADDCLASS)) {
		replace(text, "[b]", "");
		replace(text, "[/b]", "");
	}

	ZeroMemory(&ppd, sizeof(ppd));
	ppd.lchIcon = LoadSkinnedIcon(SKINICON_OTHER_MIRANDA);
	lstrcpy(ppd.lpzContactName, title);
	lstrcpy(ppd.lpzText, text);
	ppd.colorBack = 0; //PopUpOptions.DefaultColour;
	ppd.colorText = 0; //PopUpOptions.DefaultTextColour;
	ppd.PluginWindowProc = NULL;

	CallService(MS_POPUP_ADDPOPUPEX, (WPARAM)&ppd,0);

	return;
}

void popup(char *title, const char* fmt, ...) {
	va_list marker;
	va_start(marker, fmt);

	char szBuf[1024];
	vsprintf(szBuf, fmt, marker);

	va_end(marker);
	popup(title, szBuf);

	return;
}

// indexed
BOOL GetDBString(char *target, char *Key, const int targetsize) {
	DBVARIANT dbv;
	BOOL returnvalue = FALSE;

	strcpy(target, "");
	if (!DBGetContactSetting(NULL, pluginid, Key, &dbv)) {
		strncpy(target, dbv.pszVal, targetsize);
		returnvalue = TRUE;
	}
	DBFreeVariant(&dbv);

	return returnvalue;
}

BOOL GetDBString(char *target, char *key, int i, int targetsize, char *defVal) {
	DBVARIANT dbv;
	BOOL returnvalue = FALSE;
	char tmp[32];

	sprintf(tmp, key, i);
	if(!DBGetContactSetting(NULL, pluginid, tmp, &dbv)) {
		strcpy(target, dbv.pszVal);
		returnvalue = TRUE;
	} else strcpy(target, defVal);
	DBFreeVariant(&dbv);

	return returnvalue;
}

char GetDBByte(char *key, int index, char defVal) {
	char tmp[32];

	sprintf(tmp, key, index);
	return DBGetContactSettingByte(NULL, pluginid, tmp, defVal);
}

int GetDBWord(char *key, int index, int defVal) {
	char tmp[32];

	sprintf(tmp, key, index);
	return DBGetContactSettingWord(NULL, pluginid, tmp, defVal);
}

void SetDBString(char *key, int index, const char *val) {
	char tmp[32];

	sprintf(tmp, key, index);
	DBWriteContactSettingString(NULL, pluginid, tmp, val);
}

void SetDBWord(char *key, int index, int val) {
	char tmp[32];

	sprintf(tmp, key, index);
	DBWriteContactSettingWord(NULL, pluginid, tmp, (WORD)val);
}



void SetDBByte(char *key, int index, char val) {
	char tmp[32];

	sprintf(tmp, key, index);
	DBWriteContactSettingByte(NULL, pluginid, tmp, val);
}

void DBDel(char *key, int index) {
	char tmp[32];

	sprintf(tmp, key, index);
	DBDeleteContactSetting(NULL, pluginid, tmp);
}

// unindexed
char GetDBByte(char *key, char defVal) { return DBGetContactSettingByte(NULL, pluginid, key, defVal); }
int GetDBWord(char *key, int defVal) { return DBGetContactSettingWord(NULL, pluginid, key, defVal); }
void SetDBWord(char *key, int val) { DBWriteContactSettingWord(NULL, pluginid, key, (WORD)val); }
void SetDBByte(char *key, char val) { DBWriteContactSettingByte(NULL, pluginid, key, val); }
void SetDBString(char *key, char *val) { DBWriteContactSettingString(NULL, pluginid, key, val); };
void DBDel(char *key) { DBDeleteContactSetting(NULL, pluginid, key); }


double FileAge(char *File) {
	struct stat filestat;
	time_t curtime;

	if (!strcmp(File, "")) return -1;
	if (stat(File, &filestat) != 0) return -1;
	if (filestat.st_mode == _S_IFDIR) return -1;

	time(&curtime);
	return difftime(curtime, filestat.st_mtime);
}

void replace(char *atext, const char *apattern,  const char *areplacement)
{
	char *pos, *last;
	long textsize;
	long patternsize;
	long replacementsize;

	pos=atext;
	patternsize=strlen(apattern);
	replacementsize=strlen(areplacement);

	do {
		last=pos;
		pos=strstr(pos, apattern);
		if(pos==NULL) break;
		textsize=strlen(last);
		memmove
		(
			pos+replacementsize,
			pos+patternsize,
			textsize-((pos-last)+patternsize)+1
		);
		strncpy(pos, areplacement, replacementsize);
		pos+=replacementsize;
	} while(pos!=NULL);
}



BOOL GetClipboardString(char *target, int targetsize) {
	BOOL returnvalue = FALSE;
	HGLOBAL   hglb; 
	LPTSTR    lptstr; 
	
	if (IsClipboardFormatAvailable(CF_TEXT)) {
		if (OpenClipboard(NULL)) {
			hglb = GetClipboardData(CF_TEXT); 
			if (hglb != NULL) { 
				lptstr = (char*)GlobalLock(hglb); 
				if (lptstr != NULL) { 
					strncpy(target, lptstr, targetsize);
					returnvalue = TRUE;
					GlobalUnlock(hglb);
				}
			}
			CloseClipboard();
		}
	}
	return returnvalue;
}

bool GetCheckVal(HWND hwndDlg, int phWnd) {
	HWND hwnd;

	hwnd=GetDlgItem(hwndDlg, phWnd);
	if (SendMessage(hwnd,BM_GETCHECK,0,0) == BST_CHECKED) return TRUE;
	else return FALSE;
}

void TextBox(const char* fmt, ...) {
	va_list marker;
	va_start(marker, fmt);

	char szBuf[1024];
	vsprintf(szBuf, fmt, marker);

	va_end(marker);
	MessageBox(NULL, szBuf, pluginid, 0);

	return;
}

void deleteProcGroup(int del) {
//	cfgGames[del].removeListItem();
	cfgGames[del].freeDBSettings();
	cfgGames[del].deleteDBSettings();

	if (del == cfgGames.size()-1) {
		cfgGames.pop_back();
	} else if (del > cfgGames.size()-1) {
		TextBox("exception: procGroup[%i] should be deleted,\nbut last procGroup has index %i", del, cfgGames.size()-1);
	} else if (del < cfgGames.size()-1) { // if not last element
//			popup("deleteProcGroup 1", "awayMessage = %s", cfgGames[del].awayMessage);

			try {
				vector<processGroupClass>::iterator p = &cfgGames[del];
				p = cfgGames.erase(p);
			} catch (...) { TextBox("p could not be erased!"); return; }

			vector<processGroupClass>(cfgGames).swap(cfgGames); // shrinks the vector to the needed size --> see cfgGames.capacity()

			if (del != cfgGames.size()-1) { // if not last element (after erase)
//				popup("deleteProcGroup 2", "awayMessage = %s", cfgGames[del].awayMessage);
				try {
					vector<processGroupClass>::iterator p = &cfgGames[del];
					cfgGames.insert(p, cfgGames[cfgGames.size()-1]);
				} catch (...) { TextBox("last item could not be copied!"); return; }
//				popup("deleteProcGroup 3", "awayMessage = %s", cfgGames[del].awayMessage);

				cfgGames.pop_back();
			}
			cfgGames[del].changeIndex(del);
	}
	saveProcGroupCount();

	if (hwndGroupList != NULL) {
		int i;

		ListView_DeleteAllItems(hwndGroupList);
		for (i=0; i<cfgGames.size(); i++) {
			cfgGames[i].resetDialogVars();
			cfgGames[i].setListItem(hwndGroupList);
		}
	}
}

void cutExtension(char *target, char *source) {
	strcpy(target, source);
/*
	int i=-1;
	while (source[++i] != char(".") && i<strlen(source)) {}

	strncpy(target, source, i);
	strcat(target, "\0");
*/
	return;
}

void setProtoStatus (const char *protoName, int statusMode, char *statusMsg) {
//	popup("trying status-change", "%s to %i", protoName, statusMode);

//	if (CallProtoService (protoName, PS_SETSTATUS, (WPARAM)statusMode, (LPARAM)0) == CALLSERVICE_NOTFOUND)
//		popup(POPUP_TITLE, "CALLSERVICE_NOTFOUND: %s", protoName);

	if (ServiceExists(MS_AWAYSYS_IGNORENEXT)) CallService (MS_AWAYSYS_IGNORENEXT, 0, 0);
	CallProtoService (protoName, PS_SETSTATUS, (WPARAM)statusMode, (LPARAM)0);

//	if (statusMsg != NULL) { // seems to suppress the correct status-msg �_�
		CallProtoService (protoName, PS_SETAWAYMSG, (WPARAM)statusMode, (LPARAM)statusMsg);
//		popup((char*)protoName, (statusMsg==NULL)?"status-msh = NULL":statusMsg);
//	} else popup((char*)protoName, "status-msg = NULL");
	
	return;
}

