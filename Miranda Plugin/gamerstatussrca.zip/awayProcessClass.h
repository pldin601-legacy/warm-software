// awayProcessClass.h: Schnittstelle f�r die Klasse awayProcessClass.
//
//////////////////////////////////////////////////////////////////////

#ifndef AWAYPROCESSCLASS_H_INCLUDED
#define AWAYPROCESSCLASS_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "common.h"

class protoManagerClass;
class processGroupClass; // foreward
class infoFileClass;
class launchInfoClass;
class processClass;

class awayProcessClass  
{
public:
	awayProcessClass();
	virtual ~awayProcessClass();

	bool isActive;
	BOOL isIgnored;
	processClass awayProc;
	processClass possibleProcess;
	BOOL isStillRunning;
	infoFileClass *launchInfo;
	statusBackupClass statusBackup;
	protoManagerClass protoMgr;

//	int oldStatus;
	BitArrayClass<int> lastProcOptions;

	void notify (char*,const char*,int=NULL);

	void setPossibleProcess(processClass*);
	void delPossibleProcess();
	BOOL activate(processClass,BOOL=FALSE); //(processGroupClass*,const char*,const char*,BOOL=FALSE);
	void deactivate(char*,BOOL);	
//	void checkStillRunning();
	int userStatusChange(WPARAM wparam, LPARAM lparam);
	void GetStatusText(char*);
	void reset(char*,BOOL);
	BOOL isRunningProcess(processClass *proc);

//	void setStatus(int,char*);
//	void ChangeAllProtoMessages(int,char*);
//	char *StatusModeToDbSetting(int,const char*);

	void saveAwayInfo();
	BOOL loadAwayInfo();
	void deleteAwayInfo();

	operator bool() const { return this->isActive; }
};

#endif // AWAYPROCESSCLASS_H_INCLUDED
