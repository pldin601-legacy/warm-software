------------------- Informer -------------------
                   v. 0.0.0.5
           Tomas Antos (c) 2006-02-02
                    freeware
------------------------------------------------

              ***** Features *****

- plays selected sound for users when they change
 status
- plays selected sound for selected users
- informs the time of two lasts changings status to
 online for each user



                ***** To-do *****

1. Installation
Copy informer.dll, sound.wav and oneuser.wav into
directory /plugins.

2. Settings
a)
If you want setup the plugin then go to Main menu
and choose "Settings Informer". It is not in 
options/plugins" list! 

On the left side there you can specify status
for not selected users. If any of them changes
to selected status the chosen sound will be played.

On the right side there you can specify status
and sound file for selected users by "NotifyMe"

If you want to show extra information about
date a and time then select checkbox "Show info in
user context menu..."

b) 
If you want to be extra informed about status
some important users then click on them in contact
list with right button on your mouse and choose
"NotifyMe".


        ***** Contact and questions *****

If you will have some questions or suggestions then
send me on my e-mail mail@t-antos.com or contact
me by icq 40533527.
----------------------------------------------------